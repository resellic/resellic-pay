# Retrofit
-keep class retrofit2.** { *; }
-keepattributes Signature
-keepattributes Exceptions

# OkHttp
-keepattributes Signature
-keepattributes *Annotation*
-keep class okhttp3.** { *; }
-keep class okio.** { *; }

# Gson
-keep class com.google.gson.** { *; }
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Room
-keep class androidx.room.** { *; }

# Hilt
-keep class dagger.hilt.** { *; }

# Keep data classes
-keep class com.resellic.smspay.data.** { *; }
-keep class com.resellic.smspay.ui.** { *; }

# Keep model classes
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Keep kotlin metadata
-keep class kotlin.Metadata { *; }
