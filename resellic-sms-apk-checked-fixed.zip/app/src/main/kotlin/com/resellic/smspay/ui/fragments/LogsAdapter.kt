package com.resellic.smspay.ui.fragments

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.resellic.smspay.data.local.SmsEntity
import com.resellic.smspay.databinding.ItemActivityBinding
import java.text.SimpleDateFormat
import java.util.Locale

class LogsAdapter : ListAdapter<SmsEntity, LogsAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemActivityBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: SmsEntity) {
            // Icon
            val iconEmoji = when (item.provider) {
                "bKash" -> "💳"
                "Nagad", "Nagad Personal", "Nagad Merchant", "Nagad Bangla QR" -> "📱"
                "BRAC Bank" -> "🏦"
                "Rocket" -> "🚀"
                "Upay" -> "💰"
                else -> "💵"
            }
            binding.activityIcon.text = iconEmoji

            // Title
            binding.activityTitle.text = "${item.provider} ${item.transactionId ?: "Payment"}"

            // Time
            val timeAgo = getTimeAgo(item.createdAt)
            binding.activityTimestamp.text = timeAgo

            // Amount
            binding.activityAmount.text = "৳${String.format("%.0f", item.amount)}"

            // Status badge
            val (statusText, statusColor) = when (item.status) {
                SmsEntity.STATUS_COMPLETED -> "✓ Sent" to android.graphics.Color.parseColor("#10b981")
                SmsEntity.STATUS_PENDING -> "🔄 Retry ${item.retryCount}/5" to android.graphics.Color.parseColor("#f59e0b")
                SmsEntity.STATUS_FAILED -> "✕ Failed" to android.graphics.Color.parseColor("#ef4444")
                else -> "Unknown" to android.graphics.Color.GRAY
            }
            binding.activityStatus.text = statusText
            // Would apply statusColor to badge background in real implementation
        }

        private fun getTimeAgo(timestamp: Long): String {
            val now = System.currentTimeMillis()
            val diff = now - timestamp
            val minutes = diff / 60000
            val hours = diff / 3600000
            val days = diff / 86400000

            return when {
                minutes < 1 -> "Just now"
                minutes < 60 -> "$minutes min ago"
                hours < 24 -> "$hours h ago"
                else -> "$days d ago"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemActivityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<SmsEntity>() {
        override fun areItemsTheSame(oldItem: SmsEntity, newItem: SmsEntity) =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: SmsEntity, newItem: SmsEntity) =
            oldItem == newItem
    }
}
