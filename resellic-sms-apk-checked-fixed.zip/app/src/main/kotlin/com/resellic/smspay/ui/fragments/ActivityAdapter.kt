package com.resellic.smspay.ui.fragments

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.resellic.smspay.R
import com.resellic.smspay.data.local.SmsEntity
import com.resellic.smspay.databinding.ItemActivityBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ActivityAdapter : ListAdapter<SmsEntity, ActivityAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemActivityBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: SmsEntity) {
            // Icon emoji
            val iconEmoji = when (item.provider) {
                "bKash" -> "💳"
                "Nagad", "Nagad Personal", "Nagad Merchant", "Nagad Bangla QR" -> "📱"
                "BRAC Bank" -> "🏦"
                "Rocket" -> "🚀"
                "Upay" -> "💰"
                else -> "💵"
            }
            binding.activityIcon.text = iconEmoji

            // Title & provider
            binding.activityTitle.text = "${item.provider} Payment"

            // Timestamp
            val dateFormat = SimpleDateFormat("MMM dd, h:mm a", Locale.getDefault())
            val timeAgo = getTimeAgo(item.createdAt)
            binding.activityTimestamp.text = timeAgo

            // Amount
            binding.activityAmount.text = "৳${String.format("%.0f", item.amount)}"

            // Status
            binding.activityStatus.text = when (item.status) {
                SmsEntity.STATUS_COMPLETED -> "✓ Completed"
                SmsEntity.STATUS_PENDING -> "🔄 Pending"
                SmsEntity.STATUS_FAILED -> "✕ Failed"
                else -> "Unknown"
            }

            // Status badge color
            val statusColor = when (item.status) {
                SmsEntity.STATUS_COMPLETED -> android.graphics.Color.parseColor("#10b981")
                SmsEntity.STATUS_PENDING -> android.graphics.Color.parseColor("#f59e0b")
                SmsEntity.STATUS_FAILED -> android.graphics.Color.parseColor("#ef4444")
                else -> android.graphics.Color.GRAY
            }
            // Apply color to status badge (would need a custom implementation)
        }

        private fun getTimeAgo(timestamp: Long): String {
            val now = System.currentTimeMillis()
            val diff = now - timestamp
            val minutes = diff / 60000
            val hours = diff / 3600000
            val days = diff / 86400000

            return when {
                minutes < 1 -> "Just now"
                minutes < 60 -> "$minutes minutes ago"
                hours < 24 -> "$hours hours ago"
                else -> "$days days ago"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemActivityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<SmsEntity>() {
        override fun areItemsTheSame(oldItem: SmsEntity, newItem: SmsEntity) =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: SmsEntity, newItem: SmsEntity) =
            oldItem == newItem
    }
}
