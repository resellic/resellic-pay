package com.resellic.smspay.worker

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.resellic.smspay.data.local.SmsDatabase
import com.resellic.smspay.data.local.SmsEntity
import com.resellic.smspay.data.remote.ApiClient
import com.resellic.smspay.data.remote.SmsWebhookRequest
import com.resellic.smspay.notification.NotificationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class SmsForwarderWorker(context: Context, params: androidx.work.WorkerParameters) :
    CoroutineWorker(context, params) {

    private val TAG = "SmsForwarder"
    private val database = SmsDatabase.getInstance(context)
    private val apiService = ApiClient.getApiService(context)
    private val sharedPrefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    override suspend fun doWork(): Result {
        return withContext(Dispatchers.IO) {
            try {
                val smsId = inputData.getInt("sms_id", -1)
                if (smsId == -1) {
                    Log.e(TAG, "Invalid SMS ID")
                    return@withContext Result.failure()
                }

                val sms = database.smsDao().getSmsById(smsId) ?: run {
                    Log.e(TAG, "SMS not found with ID: $smsId")
                    return@withContext Result.failure()
                }

                // Check if already completed
                if (sms.status == SmsEntity.STATUS_COMPLETED) {
                    Log.d(TAG, "SMS already completed: $smsId")
                    return@withContext Result.success()
                }

                // Check max retries
                if (sms.retryCount >= SmsEntity.MAX_RETRIES) {
                    Log.e(TAG, "Max retries reached for SMS: $smsId")
                    updateSmsStatus(sms, SmsEntity.STATUS_FAILED, "Max retries reached")
                    NotificationManager.showErrorNotification(
                        applicationContext,
                        sms.provider,
                        sms.amount,
                        "Max retries exceeded"
                    )
                    return@withContext Result.failure()
                }

                // Get API key
                val apiKey = sharedPrefs.getString("api_key", "") ?: ""
                if (apiKey.isEmpty()) {
                    Log.e(TAG, "API key not configured")
                    scheduleRetry(smsId, sms)
                    return@withContext Result.retry()
                }

                // Create webhook request
                val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                    .format(Date(sms.createdAt))

                val request = SmsWebhookRequest(
                    provider = sms.provider,
                    transactionId = sms.transactionId,
                    amount = sms.amount,
                    sender = sms.sender,
                    timestamp = timestamp,
                    smsContent = sms.smsContent
                )

                // Send webhook
                val response = try {
                    apiService.sendSmsWebhook(
                        "Bearer $apiKey",
                        request = request
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Network error: ${e.message}", e)
                    // Update retry count and reschedule
                    val updatedSms = sms.copy(
                        retryCount = sms.retryCount + 1,
                        lastError = "Network error: ${e.message}",
                        updatedAt = System.currentTimeMillis()
                    )
                    database.smsDao().updateSms(updatedSms)
                    scheduleRetry(smsId, updatedSms)
                    return@withContext Result.retry()
                }

                if (response.isSuccessful && response.body()?.success == true) {
                    // Success
                    Log.d(TAG, "Webhook sent successfully for SMS: $smsId")
                    updateSmsStatus(sms, SmsEntity.STATUS_COMPLETED, null)
                    NotificationManager.showSmsNotification(
                        applicationContext,
                        sms.provider,
                        sms.amount,
                        SmsEntity.STATUS_COMPLETED
                    )
                    return@withContext Result.success()
                } else {
                    // Server error or unsuccessful response
                    val errorMessage = response.body()?.message ?: "Server error"
                    Log.e(TAG, "Webhook failed: $errorMessage, Status: ${response.code()}")
                    
                    val updatedSms = sms.copy(
                        retryCount = sms.retryCount + 1,
                        lastError = errorMessage,
                        updatedAt = System.currentTimeMillis(),
                        lastWebhookTime = System.currentTimeMillis()
                    )
                    database.smsDao().updateSms(updatedSms)

                    if (sms.retryCount + 1 >= SmsEntity.MAX_RETRIES) {
                        NotificationManager.showErrorNotification(
                            applicationContext,
                            sms.provider,
                            sms.amount,
                            errorMessage
                        )
                        return@withContext Result.failure()
                    }

                    NotificationManager.showRetryNotification(
                        applicationContext,
                        sms.provider,
                        sms.amount,
                        sms.retryCount + 1
                    )

                    scheduleRetry(smsId, updatedSms)
                    return@withContext Result.retry()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error: ${e.message}", e)
                return@withContext Result.retry()
            }
        }
    }

    private suspend fun updateSmsStatus(sms: SmsEntity, status: String, error: String?) {
        val updated = sms.copy(
            status = status,
            lastError = error,
            updatedAt = System.currentTimeMillis(),
            lastWebhookTime = System.currentTimeMillis()
        )
        database.smsDao().updateSms(updated)
        Log.d(TAG, "SMS status updated to $status: ${sms.id}")
    }

    private fun scheduleRetry(smsId: Int, sms: SmsEntity) {
        // Exponential backoff: 1, 2, 5, 10, 20 minutes
        val delayMinutes = when (sms.retryCount) {
            0 -> 1L
            1 -> 2L
            2 -> 5L
            3 -> 10L
            else -> 20L
        }

        val data = workDataOf(
            "sms_id" to smsId,
            "provider" to sms.provider,
            "amount" to sms.amount
        )

        val retryRequest = OneTimeWorkRequestBuilder<SmsForwarderWorker>()
            .setInputData(data)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(applicationContext).enqueueUniqueWork(
            "sms_forward_${smsId}_retry",
            androidx.work.ExistingWorkPolicy.KEEP,
            listOf(retryRequest)
        )

        Log.d(TAG, "Retry scheduled for SMS $smsId in $delayMinutes minutes (attempt ${sms.retryCount + 1})")
    }

    companion object {
        const val INITIAL_DELAY_MILLIS = 10_000L
    }
}
