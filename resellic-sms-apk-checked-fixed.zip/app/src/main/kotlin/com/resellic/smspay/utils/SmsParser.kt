package com.resellic.smspay.utils

data class ParsedSms(
    val provider: String,
    val transactionId: String?,
    val amount: Double,
    val sender: String
)

object SmsParser {
    
    fun parseSms(sender: String, content: String): ParsedSms? {
        return when {
            sender.equals("bKash", ignoreCase = true) -> parseBKash(content)
            sender.equals("NAGAD", ignoreCase = true) -> parseNagad(content)
            sender.contains("BRAC", ignoreCase = true) -> parseBracBank(content)
            content.contains("Upay", ignoreCase = true) -> parseUpay(content)
            content.contains("Rocket", ignoreCase = true) -> parseRocket(content)
            else -> null
        }
    }

    private fun parseBKash(content: String): ParsedSms? {
        // bKash: You have received Tk X from 01XXXXXXXXX. Fee Tk 0.00. Balance Tk Y. TrxID XXXXXXXX at DD/MM/YYYY HH:MM
        val amountRegex = """received Tk\s+([\d.]+)""".toRegex()
        val txnIdRegex = """TrxID\s+(\w+)""".toRegex()
        
        val amount = amountRegex.find(content)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val txnId = txnIdRegex.find(content)?.groupValues?.get(1)

        return ParsedSms(
            provider = "bKash",
            transactionId = txnId,
            amount = amount,
            sender = "bKash"
        )
    }

    private fun parseNagad(content: String): ParsedSms? {
        // Money Received. Amount: Tk X Sender: 01XXXXXXXXX Ref: N/A TxnID: XXXXXXXX Balance: Tk Y DD/MM/YYYY HH:MM
        // Payment Received. Amount: Tk X Customer: 01XXXXXXXXX TxnID: XXXXXXXX Balance: Tk Y DD/MM/YYYY HH:MM
        // Payment - Bangla QR Successfully Received. Amount: Tk X Txn ID: XXXXXXXX DD/MM/YYYY HH:MM
        
        val amountRegex = """Amount:\s*Tk\s+([\d.]+)""".toRegex()
        val txnIdRegex = """(?:TxnID|Txn ID):\s*(\w+)""".toRegex()
        
        val amount = amountRegex.find(content)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val txnId = txnIdRegex.find(content)?.groupValues?.get(1)

        val type = when {
            content.contains("Bangla QR", ignoreCase = true) -> "Nagad Bangla QR"
            content.contains("Payment Received", ignoreCase = true) -> "Nagad Merchant"
            else -> "Nagad Personal"
        }

        return ParsedSms(
            provider = type,
            transactionId = txnId,
            amount = amount,
            sender = "NAGAD"
        )
    }

    private fun parseBracBank(content: String): ParsedSms? {
        // Your BRAC Bank A/C#XXXX**XXX has been credited by TK X by EFT from other bank. A/C balance is TK Y. Query:16221.
        val amountRegex = """credited by TK\s+([\d.]+)""".toRegex()
        
        val amount = amountRegex.find(content)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null

        return ParsedSms(
            provider = "BRAC Bank",
            transactionId = null,  // BRAC doesn't provide TxnID in SMS
            amount = amount,
            sender = "BRAC-BANK"
        )
    }

    private fun parseUpay(content: String): ParsedSms? {
        val amountRegex = """Tk\.\s+([\d.]+)""".toRegex()
        val txnIdRegex = """(?:TxnID|Ref):\s*(\w+)""".toRegex()
        
        val amount = amountRegex.find(content)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val txnId = txnIdRegex.find(content)?.groupValues?.get(1)

        return ParsedSms(
            provider = "Upay",
            transactionId = txnId,
            amount = amount,
            sender = "Upay"
        )
    }

    private fun parseRocket(content: String): ParsedSms? {
        val amountRegex = """Tk\s+([\d.]+)""".toRegex()
        val txnIdRegex = """(?:TxnID|Ref):\s*(\w+)""".toRegex()
        
        val amount = amountRegex.find(content)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val txnId = txnIdRegex.find(content)?.groupValues?.get(1)

        return ParsedSms(
            provider = "Rocket",
            transactionId = txnId,
            amount = amount,
            sender = "Rocket"
        )
    }
}
