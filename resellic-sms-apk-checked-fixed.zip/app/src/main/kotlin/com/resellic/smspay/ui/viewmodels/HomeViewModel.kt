package com.resellic.smspay.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import com.resellic.smspay.data.local.SmsDatabase
import com.resellic.smspay.data.local.SmsEntity
import kotlinx.coroutines.flow.combine

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = SmsDatabase.getInstance(application)
    private val smsDao = database.smsDao()

    val completedCount: LiveData<Int> = smsDao.getCountByStatus(SmsEntity.STATUS_COMPLETED).asLiveData()
    val pendingCount: LiveData<Int> = smsDao.getCountByStatus(SmsEntity.STATUS_PENDING).asLiveData()
    val failedCount: LiveData<Int> = smsDao.getCountByStatus(SmsEntity.STATUS_FAILED).asLiveData()

    val recentActivityList: LiveData<List<SmsEntity>> = 
        smsDao.getSmsWithStatus(SmsEntity.STATUS_COMPLETED)
            .combine(smsDao.getSmsWithStatus(SmsEntity.STATUS_PENDING)) { completed, pending ->
                (completed + pending)
                    .sortedByDescending { it.createdAt }
                    .take(7)
            }
            .asLiveData()

    private val _refreshTrigger = MutableLiveData<Unit>()
    
    fun refreshData() {
        _refreshTrigger.value = Unit
    }
}
