package com.resellic.smspay.data.remote

import com.google.gson.annotations.SerializedName

data class SmsWebhookRequest(
    @SerializedName("provider")
    val provider: String,
    @SerializedName("txn_id")
    val transactionId: String?,
    @SerializedName("amount")
    val amount: Double,
    @SerializedName("sender")
    val sender: String,
    @SerializedName("timestamp")
    val timestamp: String,
    @SerializedName("sms_content")
    val smsContent: String
)

data class SmsWebhookResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("status")
    val status: String?,
    @SerializedName("message")
    val message: String?
)

data class ErrorResponse(
    @SerializedName("error")
    val error: String?,
    @SerializedName("message")
    val message: String?
)
