package com.resellic.smspay.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsMessage
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.resellic.smspay.data.local.SmsDatabase
import com.resellic.smspay.data.local.SmsEntity
import com.resellic.smspay.notification.NotificationManager
import com.resellic.smspay.utils.SmsParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class SmsReceiver : BroadcastReceiver() {
    
    private val TAG = "SmsReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "SMS received")
        
        if (context == null || intent == null) return
        if (intent.action != "android.provider.Telephony.SMS_RECEIVED") return

        val bundle = intent.extras ?: return
        val pdus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            bundle.getSerializable("pdus", Array<Any>::class.java) as? Array<Any>
        } else {
            @Suppress("DEPRECATION")
            bundle.get("pdus") as? Array<Any>
        } ?: return

        val messages = mutableListOf<SmsMessage>()
        for (pdu in pdus) {
            val sms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val format = bundle.getString("format", "")
                SmsMessage.createFromPdu(pdu as ByteArray, format)
            } else {
                @Suppress("DEPRECATION")
                SmsMessage.createFromPdu(pdu as ByteArray)
            }
            messages.add(sms)
        }

        // Process each SMS message
        for (message in messages) {
            val sender = message.originatingAddress ?: continue
            val content = message.messageBody
            
            Log.d(TAG, "SMS from: $sender, Content: $content")
            
            // Parse SMS
            val parsed = SmsParser.parseSms(sender, content) ?: run {
                Log.d(TAG, "SMS not recognized: $sender")
                continue
            }

            // Save to database
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val database = SmsDatabase.getInstance(context)
                    val smsEntity = SmsEntity(
                        provider = parsed.provider,
                        transactionId = parsed.transactionId,
                        amount = parsed.amount,
                        sender = parsed.sender,
                        smsContent = content,
                        status = SmsEntity.STATUS_PENDING,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                    
                    val id = database.smsDao().insertSms(smsEntity)
                    Log.d(TAG, "SMS saved to database with ID: $id")

                    // Show notification
                    NotificationManager.showSmsNotification(
                        context,
                        parsed.provider,
                        parsed.amount,
                        SmsEntity.STATUS_PENDING
                    )

                    // Schedule webhook job immediately
                    scheduleSmsForwarder(context, id.toInt(), parsed.provider, parsed.amount)
                } catch (e: Exception) {
                    Log.e(TAG, "Error saving SMS: ${e.message}", e)
                }
            }
        }

        // Don't abort broadcast, let other apps handle it too
    }

    private fun scheduleSmsForwarder(context: Context, smsId: Int, provider: String, amount: Double) {
        val data = workDataOf(
            "sms_id" to smsId,
            "provider" to provider,
            "amount" to amount
        )

        val forwarderRequest = OneTimeWorkRequestBuilder<SmsForwarderWorker>()
            .setInputData(data)
            .setBackoffPolicy(
                BackoffPolicy.EXPONENTIAL,
                SmsForwarderWorker.INITIAL_DELAY_MILLIS,
                TimeUnit.MILLISECONDS
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "sms_forward_$smsId",
            androidx.work.ExistingWorkPolicy.KEEP,
            forwarderRequest
        )

        Log.d(TAG, "SMS forwarder scheduled for ID: $smsId")
    }
}
