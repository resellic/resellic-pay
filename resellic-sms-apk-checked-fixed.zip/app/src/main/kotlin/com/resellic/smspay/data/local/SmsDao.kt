package com.resellic.smspay.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SmsDao {
    
    @Insert
    suspend fun insertSms(sms: SmsEntity): Long

    @Update
    suspend fun updateSms(sms: SmsEntity)

    @Query("SELECT * FROM sms WHERE id = :id")
    suspend fun getSmsById(id: Int): SmsEntity?

    @Query("SELECT * FROM sms ORDER BY createdAt DESC LIMIT :limit OFFSET :offset")
    suspend fun getAllSms(limit: Int = 50, offset: Int = 0): List<SmsEntity>

    @Query("SELECT * FROM sms WHERE status = :status ORDER BY createdAt DESC")
    fun getSmsWithStatus(status: String): Flow<List<SmsEntity>>

    @Query("SELECT * FROM sms WHERE status = :status LIMIT :limit")
    suspend fun getSmsWithStatusLimit(status: String, limit: Int): List<SmsEntity>

    @Query("SELECT * FROM sms WHERE transactionId = :txnId")
    suspend fun getSmsByTransactionId(txnId: String): SmsEntity?

    @Query("SELECT COUNT(*) FROM sms WHERE status = :status")
    fun getCountByStatus(status: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM sms WHERE status = :status AND createdAt >= :sinceTime")
    suspend fun getCountByStatusSince(status: String, sinceTime: Long): Int

    @Query("SELECT * FROM sms WHERE status = 'pending' AND retryCount < :maxRetries AND (lastWebhookTime IS NULL OR lastWebhookTime < :retryAfter) ORDER BY createdAt ASC LIMIT :limit")
    suspend fun getPendingSmsForRetry(maxRetries: Int, retryAfter: Long, limit: Int = 10): List<SmsEntity>

    @Query("SELECT * FROM sms WHERE createdAt >= :sinceTime ORDER BY createdAt DESC")
    fun getSmsSince(sinceTime: Long): Flow<List<SmsEntity>>

    @Query("DELETE FROM sms WHERE id = :id")
    suspend fun deleteSms(id: Int)

    @Query("DELETE FROM sms")
    suspend fun deleteAllSms()
}
