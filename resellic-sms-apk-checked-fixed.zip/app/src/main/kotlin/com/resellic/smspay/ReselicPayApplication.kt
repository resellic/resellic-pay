package com.resellic.smspay

import android.app.Application
import androidx.work.Configuration
import com.resellic.smspay.notification.NotificationManager
import dagger.hilt.android.HiltAndroidApp
import android.util.Log

@HiltAndroidApp
class ReselicPayApplication : Application(), Configuration.Provider {
    
    private val TAG = "ReselicPayApp"

    override fun onCreate() {
        super.onCreate()
        
        Log.d(TAG, "Application initialized")
        
        // Create notification channel
        NotificationManager.createNotificationChannel(this)
    }

    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setMinimumLoggingLevel(Log.DEBUG)
            .build()
    }
}
