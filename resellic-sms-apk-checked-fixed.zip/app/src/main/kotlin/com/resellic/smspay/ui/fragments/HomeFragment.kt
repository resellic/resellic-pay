package com.resellic.smspay.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.resellic.smspay.databinding.FragmentHomeBinding
import com.resellic.smspay.ui.viewmodels.HomeViewModel

class HomeFragment : Fragment() {
    
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var activityAdapter: ActivityAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup RecyclerView
        activityAdapter = ActivityAdapter()
        binding.activityList.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = activityAdapter
            setHasFixedSize(true)
        }

        // Observe data
        viewModel.completedCount.observe(viewLifecycleOwner) { count ->
            binding.summaryCompletedCount.text = count.toString()
        }

        viewModel.pendingCount.observe(viewLifecycleOwner) { count ->
            binding.summaryPendingCount.text = count.toString()
        }

        viewModel.failedCount.observe(viewLifecycleOwner) { count ->
            binding.summaryFailedCount.text = count.toString()
        }

        viewModel.recentActivityList.observe(viewLifecycleOwner) { items ->
            activityAdapter.submitList(items)
        }

        // Setup refresh
        binding.scanButton.setOnClickListener {
            viewModel.refreshData()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
