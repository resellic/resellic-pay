package com.resellic.smspay.di

import android.content.Context
import androidx.room.Room
import com.resellic.smspay.data.local.SmsDatabase
import com.resellic.smspay.data.remote.ApiClient
import com.resellic.smspay.data.remote.ApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Singleton
    @Provides
    fun provideDatabase(@ApplicationContext context: Context): SmsDatabase {
        return SmsDatabase.getInstance(context)
    }

    @Singleton
    @Provides
    fun provideSmsDao(database: SmsDatabase) = database.smsDao()

    @Singleton
    @Provides
    fun provideApiService(@ApplicationContext context: Context): ApiService {
        return ApiClient.getApiService(context)
    }
}
