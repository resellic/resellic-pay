package com.resellic.smspay.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import com.resellic.smspay.data.local.SmsDatabase
import com.resellic.smspay.data.local.SmsEntity
import kotlinx.coroutines.flow.combine

class LogsViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = SmsDatabase.getInstance(application)
    private val smsDao = database.smsDao()

    private val _selectedStatus = MutableLiveData<String?>(null)
    val selectedStatus: LiveData<String?> = _selectedStatus

    val logsList: LiveData<List<SmsEntity>> = smsDao.getSmsWithStatus(SmsEntity.STATUS_COMPLETED)
        .combine(smsDao.getSmsWithStatus(SmsEntity.STATUS_PENDING)) { completed, pending ->
            (completed + pending)
                .sortedByDescending { it.createdAt }
        }
        .combine(smsDao.getSmsWithStatus(SmsEntity.STATUS_FAILED)) { prevList, failed ->
            (prevList + failed)
                .sortedByDescending { it.createdAt }
                .take(50)
        }
        .asLiveData()

    val completedCount: LiveData<Int> = smsDao.getCountByStatus(SmsEntity.STATUS_COMPLETED).asLiveData()
    val pendingCount: LiveData<Int> = smsDao.getCountByStatus(SmsEntity.STATUS_PENDING).asLiveData()
    val failedCount: LiveData<Int> = smsDao.getCountByStatus(SmsEntity.STATUS_FAILED).asLiveData()

    fun setStatusFilter(status: String?) {
        _selectedStatus.value = status
    }
}
