package com.resellic.smspay.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "sms")
data class SmsEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val provider: String,  // bKash, Nagad, BRAC-BANK, Upay, Rocket
    val transactionId: String?,
    val amount: Double,
    val sender: String,
    val smsContent: String,
    val status: String,  // pending, completed, failed
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0,
    val lastError: String? = null,
    val webhookAttempts: Int = 0,
    val lastWebhookTime: Long? = null
) {
    companion object {
        const val STATUS_PENDING = "pending"
        const val STATUS_COMPLETED = "completed"
        const val STATUS_FAILED = "failed"
        const val MAX_RETRIES = 5
        const val RETRY_INTERVAL_MINUTES = 1  // Start with 1 minute
    }
}
