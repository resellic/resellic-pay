package com.resellic.smspay.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.resellic.smspay.data.local.SmsDatabase
import com.resellic.smspay.data.local.SmsEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class BootCompletedReceiver : BroadcastReceiver() {
    
    private val TAG = "BootReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null) return
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        Log.d(TAG, "Device boot completed, rescheduling pending SMS")

        // Re-schedule all pending SMS for forwarding
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val database = SmsDatabase.getInstance(context)
                val pendingSmsList = database.smsDao()
                    .getPendingSmsForRetry(
                        maxRetries = SmsEntity.MAX_RETRIES,
                        retryAfter = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(1),
                        limit = 100
                    )

                Log.d(TAG, "Found ${pendingSmsList.size} pending SMS to reschedule")

                for (sms in pendingSmsList) {
                    val data = workDataOf(
                        "sms_id" to sms.id,
                        "provider" to sms.provider,
                        "amount" to sms.amount
                    )

                    val forwarderRequest = OneTimeWorkRequestBuilder<SmsForwarderWorker>()
                        .setInputData(data)
                        .setInitialDelay(5, TimeUnit.SECONDS)  // Small delay to let system stabilize
                        .build()

                    WorkManager.getInstance(context).enqueueUniqueWork(
                        "sms_forward_${sms.id}_boot",
                        androidx.work.ExistingWorkPolicy.KEEP,
                        forwarderRequest
                    )
                }

                Log.d(TAG, "Rescheduled ${pendingSmsList.size} SMS for forwarding")
            } catch (e: Exception) {
                Log.e(TAG, "Error rescheduling SMS: ${e.message}", e)
            }
        }
    }
}
