package com.resellic.smspay.ui.viewmodels

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    
    private val sharedPrefs: SharedPreferences = 
        application.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    private val _apiKey = MutableLiveData<String>()
    val apiKey: LiveData<String> = _apiKey

    private val _webhookUrl = MutableLiveData<String>()
    val webhookUrl: LiveData<String> = _webhookUrl

    init {
        loadSettings()
    }

    private fun loadSettings() {
        val key = sharedPrefs.getString("api_key", "") ?: ""
        val masked = if (key.length > 16) {
            "${key.substring(0, 4)}${".".repeat(12)}${key.takeLast(4)}"
        } else {
            "Not configured"
        }
        _apiKey.value = masked

        val url = sharedPrefs.getString("webhook_url", "https://pay.resellic.com/api/sms-webhook.php") ?: ""
        _webhookUrl.value = url
    }

    fun saveApiKey(newKey: String) {
        if (newKey.isNotEmpty()) {
            sharedPrefs.edit().putString("api_key", newKey).apply()
            val masked = "${newKey.substring(0, 4)}${".".repeat(12)}${newKey.takeLast(4)}"
            _apiKey.value = masked
        }
    }

    fun saveWebhookUrl(url: String) {
        if (url.isNotEmpty()) {
            sharedPrefs.edit().putString("webhook_url", url).apply()
            _webhookUrl.value = url
        }
    }

    fun getFullApiKey(): String {
        return sharedPrefs.getString("api_key", "") ?: ""
    }

    fun hasApiKey(): Boolean {
        return !getFullApiKey().isEmpty()
    }
}
