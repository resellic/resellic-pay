package com.resellic.smspay.ui.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.resellic.smspay.data.local.SmsEntity
import com.resellic.smspay.databinding.FragmentLogsBinding
import com.resellic.smspay.ui.viewmodels.LogsViewModel

class LogsFragment : Fragment() {
    
    private var _binding: FragmentLogsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LogsViewModel by viewModels()
    private lateinit var logsAdapter: LogsAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLogsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup RecyclerView with click handler
        logsAdapter = LogsAdapter { item ->
            showDetailsModal(item)
        }
        binding.logsList.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = logsAdapter
            setHasFixedSize(true)
        }

        // Observe logs
        viewModel.logsList.observe(viewLifecycleOwner) { items ->
            logsAdapter.submitList(items)
            binding.emptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            binding.logsList.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun showDetailsModal(item: SmsEntity) {
        val statusText = when (item.status) {
            SmsEntity.STATUS_COMPLETED -> "Completed"
            SmsEntity.STATUS_PENDING -> "Pending"
            SmsEntity.STATUS_FAILED -> "Failed"
            else -> "Unknown"
        }

        // Create custom dialog view with header
        val mainView = LinearLayout(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
        }

        // Blue Header
        val headerView = LinearLayout(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF1E40AF.toInt())
            setPadding(32, 24, 32, 24)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val headerTitle = TextView(requireContext()).apply {
            text = when (item.status) {
                SmsEntity.STATUS_COMPLETED -> "✓ Completed"
                SmsEntity.STATUS_PENDING -> "🔄 Pending"
                SmsEntity.STATUS_FAILED -> "✕ Failed"
                else -> "Details"
            }
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtn = TextView(requireContext()).apply {
            text = "✕"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        headerView.addView(headerTitle)
        headerView.addView(closeBtn)
        mainView.addView(headerView)

        // Content area
        val contentView = LinearLayout(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(32, 24, 32, 24)
        }

        // Add fields
        addFieldWithDivider(contentView, "Provider", item.provider)
        addFieldWithDivider(contentView, "Transaction ID", item.transactionId ?: "N/A")
        addFieldWithDivider(contentView, "Amount", "৳${String.format("%.0f", item.amount)}")
        addFieldWithDivider(contentView, "Sender", item.sender ?: "N/A")
        addFieldWithDivider(contentView, "SMS Received", formatTime(item.createdAt))
        addFieldWithDivider(contentView, "Webhook Sent", formatTime(item.updatedAt))

        // Status row
        val statusRow = LinearLayout(contentView.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 16 }
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val statusLabel = TextView(requireContext()).apply {
            text = "Status"
            textSize = 14f
            setTextColor(0xFF9CA3AF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val statusBadge = Button(requireContext()).apply {
            text = when (item.status) {
                SmsEntity.STATUS_COMPLETED -> "✓ Completed"
                SmsEntity.STATUS_PENDING -> "🔄 Pending"
                SmsEntity.STATUS_FAILED -> "✕ Failed"
                else -> "Unknown"
            }
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF10B981.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                56
            )
            isEnabled = false
            textSize = 14f
        }

        statusRow.addView(statusLabel)
        statusRow.addView(statusBadge)
        contentView.addView(statusRow)

        // Copy button
        val copyBtn = Button(requireContext()).apply {
            text = "📋 Copy Details"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF10B981.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                56
            ).apply { topMargin = 24 }
            setOnClickListener {
                val details = """
                    Provider: ${item.provider}
                    Transaction ID: ${item.transactionId ?: "N/A"}
                    Amount: ৳${String.format("%.0f", item.amount)}
                    Sender: ${item.sender ?: "N/A"}
                    SMS Received: ${formatTime(item.createdAt)}
                    Webhook Sent: ${formatTime(item.updatedAt)}
                    Status: $statusText
                """.trimIndent()
                val clipboard = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = android.content.ClipData.newPlainText("Details", details)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(requireContext(), "Details copied", Toast.LENGTH_SHORT).show()
            }
            textSize = 14f
        }
        contentView.addView(copyBtn)

        mainView.addView(contentView)

        val dialog = AlertDialog.Builder(requireContext())
            .setView(mainView)
            .setCancelable(true)
            .show()

        closeBtn.setOnClickListener {
            dialog.dismiss()
        }
    }

    private fun addFieldWithDivider(container: LinearLayout, label: String, value: String) {
        val row = LinearLayout(container.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 16 }
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val labelView = TextView(container.context).apply {
            text = label
            textSize = 14f
            setTextColor(0xFF9CA3AF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val valueView = TextView(container.context).apply {
            text = value
            textSize = 14f
            setTextColor(0xFF000000.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        row.addView(labelView)
        row.addView(valueView)
        container.addView(row)

        val divider = View(container.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                1
            ).apply { topMargin = 16 }
            setBackgroundColor(0xFFE5E7EB.toInt())
        }
        container.addView(divider)
    }

    private fun formatTime(timestamp: Long): String {
        val sdf = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
        return sdf.format(timestamp)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
