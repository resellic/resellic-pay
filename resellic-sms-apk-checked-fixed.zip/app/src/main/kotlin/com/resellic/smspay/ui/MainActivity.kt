package com.resellic.smspay.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.resellic.smspay.R
import com.resellic.smspay.databinding.ActivityMainBinding
import com.resellic.smspay.notification.NotificationManager
import com.resellic.smspay.ui.fragments.HomeFragment
import com.resellic.smspay.ui.fragments.LogsFragment
import com.resellic.smspay.ui.fragments.SettingsFragment

class MainActivity : AppCompatActivity() {
    
    private val TAG = "MainActivity"
    private lateinit var binding: ActivityMainBinding
    private var currentTabIndex = 0

    private val requiredPermissions = listOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.INTERNET,
        Manifest.permission.RECEIVE_BOOT_COMPLETED
    )

    private val optionalPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(Manifest.permission.SCHEDULE_EXACT_ALARM)
    } else {
        emptyList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Create notification channel
        NotificationManager.createNotificationChannel(this)

        // Check and request permissions
        checkAndRequestPermissions()

        // Setup bottom navigation
        setupTabNavigation()

        // Load initial fragment
        val tabIndex = intent.getIntExtra("tab", 0)
        selectTab(tabIndex)
    }

    private fun setupTabNavigation() {
        binding.navHome.setOnClickListener { selectTab(0) }
        binding.navLogs.setOnClickListener { selectTab(1) }
        binding.navSettings.setOnClickListener { selectTab(2) }
    }

    private fun selectTab(index: Int) {
        currentTabIndex = index
        val fragment = when (index) {
            0 -> HomeFragment()
            1 -> LogsFragment()
            2 -> SettingsFragment()
            else -> HomeFragment()
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.nav_host_fragment, fragment)
            .commit()

        // Update button states (you can add visual indicators here)
        updateTabIndicators(index)
    }

    private fun updateTabIndicators(selectedIndex: Int) {
        // Update button appearance based on selected tab
        // You can add color/alpha changes here
    }

    private fun checkAndRequestPermissions() {
        val missingPermissions = mutableListOf<String>()

        // Check required permissions
        for (permission in requiredPermissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission)
                Log.w(TAG, "Missing permission: $permission")
            }
        }

        // Check optional permissions (don't fail if missing)
        for (permission in optionalPermissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "Missing optional permission: $permission")
            }
        }

        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                missingPermissions.toTypedArray(),
                PERMISSION_REQUEST_CODE
            )
        } else {
            Log.d(TAG, "All required permissions granted")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val deniedPermissions = mutableListOf<String>()
            
            for (i in permissions.indices) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    deniedPermissions.add(permissions[i])
                    Log.w(TAG, "Permission denied: ${permissions[i]}")
                }
            }

            if (deniedPermissions.isEmpty()) {
                Log.d(TAG, "All permissions granted")
            } else {
                Log.w(TAG, "Some permissions denied: $deniedPermissions")
            }
        }
    }

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
    }
}
