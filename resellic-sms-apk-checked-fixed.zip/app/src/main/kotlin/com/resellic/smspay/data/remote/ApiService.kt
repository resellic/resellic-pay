package com.resellic.smspay.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface ApiService {
    
    @POST("api/sms-webhook.php")
    suspend fun sendSmsWebhook(
        @Header("Authorization") authorization: String,
        @Header("Content-Type") contentType: String = "application/json",
        @Body request: SmsWebhookRequest
    ): Response<SmsWebhookResponse>
}
