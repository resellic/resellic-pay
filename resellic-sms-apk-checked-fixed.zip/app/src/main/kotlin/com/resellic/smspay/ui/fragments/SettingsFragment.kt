package com.resellic.smspay.ui.fragments

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.resellic.smspay.databinding.FragmentSettingsBinding
import com.resellic.smspay.ui.viewmodels.SettingsViewModel

class SettingsFragment : Fragment() {
    
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Observe API key and display masked
        viewModel.apiKey.observe(viewLifecycleOwner) { key ->
            if (key.isNotEmpty() && key.length > 8) {
                // Mask: show first 4 and last 4 chars
                val masked = key.substring(0, 4) + " " + ".".repeat(key.length - 8) + " " + key.substring(key.length - 4)
                binding.apiKeyInput.setText(masked)
            } else {
                binding.apiKeyInput.setText("Not configured")
            }
        }

        // Setup API buttons
        binding.changeApiKeyBtn.setOnClickListener {
            showApiKeyDialog()
        }

        binding.saveApiKeyBtn.setOnClickListener {
            showApiKeyDialog()
        }

        // Setup permissions display with click handlers
        setupPermissionsDisplay()
    }

    private fun setupPermissionsDisplay() {
        binding.permissionsContainer.removeAllViews()

        val permissionsList = listOf(
            Manifest.permission.RECEIVE_SMS to ("📨 Receive SMS" to "Allow app to receive incoming payment SMS"),
            Manifest.permission.READ_SMS to ("📖 Read SMS" to "Allow app to read SMS for sync"),
            Manifest.permission.ACCESS_NETWORK_STATE to ("🔋 Battery Optimization" to "Allow app to stay active during sync"),
            Manifest.permission.SCHEDULE_EXACT_ALARM to ("🚀 Auto Start" to "Allow app to start on device boot")
        )

        for ((permission, titleDesc) in permissionsList) {
            val (title, description) = titleDesc

            val itemLayout = LinearLayout(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                orientation = LinearLayout.VERTICAL
                setPadding(32, 24, 32, 24)
                isClickable = true
                isFocusable = true
                setBackgroundColor(0xFFFFFFFF.toInt())
            }

            // Title
            val titleView = TextView(requireContext()).apply {
                text = title
                textSize = 16f
                setTextColor(0xFF000000.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            // Description
            val descView = TextView(requireContext()).apply {
                text = description
                textSize = 13f
                setTextColor(0xFF9CA3AF.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = 8
                }
            }

            itemLayout.addView(titleView)
            itemLayout.addView(descView)

            // Click listener to request permission
            itemLayout.setOnClickListener {
                requestPermission(permission, title)
            }

            binding.permissionsContainer.addView(itemLayout)

            // Divider
            val divider = View(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1
                )
                setBackgroundColor(0xFFE5E7EB.toInt())
            }
            binding.permissionsContainer.addView(divider)
        }
    }

    private fun requestPermission(permission: String, permissionName: String) {
        val isGranted = ContextCompat.checkSelfPermission(
            requireContext(),
            permission
        ) == PackageManager.PERMISSION_GRANTED

        if (isGranted) {
            Toast.makeText(requireContext(), "$permissionName already granted", Toast.LENGTH_SHORT).show()
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(permission),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun showApiKeyDialog() {
        val input = EditText(requireContext()).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "Enter Resellic Pay API key (min 20 chars)"
            setPadding(48, 32, 48, 32)
            setTextColor(0xFF000000.toInt())
            setHintTextColor(0xFFCCC.toInt())
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Change API Key")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newKey = input.text.toString().trim()
                if (newKey.isEmpty()) {
                    Toast.makeText(requireContext(), "API key cannot be empty", Toast.LENGTH_SHORT).show()
                } else if (newKey.length < 20) {
                    Toast.makeText(requireContext(), "API key must be at least 20 characters", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.saveApiKey(newKey)
                    Toast.makeText(requireContext(), "API Key saved successfully", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .setCancelable(true)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
