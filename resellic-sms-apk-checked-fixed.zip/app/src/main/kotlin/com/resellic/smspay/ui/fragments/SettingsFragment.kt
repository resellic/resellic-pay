package com.resellic.smspay.ui.fragments

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.resellic.smspay.databinding.FragmentSettingsBinding
import com.resellic.smspay.ui.viewmodels.SettingsViewModel

class SettingsFragment : Fragment() {
    
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.apiKey.observe(viewLifecycleOwner) { key ->
            if (key.isNotEmpty()) {
                val masked = key.take(4) + " " + ".".repeat(16) + " " + key.takeLast(4)
                binding.apiKeyInput.setText(masked)
            } else {
                binding.apiKeyInput.setText("Not configured")
            }
        }

        binding.changeApiKeyBtn.setOnClickListener {
            showApiKeyDialog()
        }

        binding.saveApiKeyBtn.setOnClickListener {
            val text = binding.apiKeyInput.text.toString()
            if (text != "Not configured" && text.length > 20) {
                viewModel.saveApiKey(text)
                Toast.makeText(requireContext(), "API Key saved", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Please enter a valid API Key", Toast.LENGTH_SHORT).show()
            }
        }

        setupPermissionToggles()
    }

    private fun showApiKeyDialog() {
        val input = android.widget.EditText(requireContext()).apply {
            hint = "Enter API Key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }

        AlertDialog.Builder(requireContext())
            .setTitle("API Configuration")
            .setMessage("Enter your API Key:")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newKey = input.text.toString()
                if (newKey.isNotEmpty() && newKey.length >= 20) {
                    viewModel.saveApiKey(newKey)
                    val masked = newKey.take(4) + " " + ".".repeat(16) + " " + newKey.takeLast(4)
                    binding.apiKeyInput.setText(masked)
                    Toast.makeText(requireContext(), "API Key updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "API Key must be at least 20 characters", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupPermissionToggles() {
        val permissions = listOf(
            Manifest.permission.RECEIVE_SMS to "📨 Receive SMS",
            Manifest.permission.READ_SMS to "📖 Read SMS",
            Manifest.permission.INTERNET to "🌐 Internet"
        )

        binding.permissionsContainer.removeAllViews()

        for ((permission, name) in permissions) {
            val isGranted = ContextCompat.checkSelfPermission(
                requireContext(),
                permission
            ) == PackageManager.PERMISSION_GRANTED

            val itemView = LinearLayout(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                orientation = LinearLayout.HORIZONTAL
                setPadding(16, 16, 16, 16)
                setBackgroundColor(android.graphics.Color.WHITE)
            }

            val nameView = TextView(requireContext()).apply {
                text = name
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
                textSize = 13f
                setTextColor(android.graphics.Color.parseColor("#333333"))
            }

            val switchView = SwitchCompat(requireContext()).apply {
                isChecked = isGranted
                isEnabled = false
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            itemView.addView(nameView)
            itemView.addView(switchView)
            binding.permissionsContainer.addView(itemView)

            // Add divider
            if (permission != permissions.last().first) {
                val divider = View(requireContext()).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1
                    ).apply {
                        setMargins(0, 0, 0, 0)
                    }
                    setBackgroundColor(android.graphics.Color.parseColor("#f0f0f0"))
                }
                binding.permissionsContainer.addView(divider)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
