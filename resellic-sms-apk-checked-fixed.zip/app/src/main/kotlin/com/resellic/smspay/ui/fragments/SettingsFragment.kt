package com.resellic.smspay.ui.fragments

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.resellic.smspay.databinding.FragmentSettingsBinding
import com.resellic.smspay.ui.viewmodels.SettingsViewModel

class SettingsFragment : Fragment() {
    
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.apiKey.observe(viewLifecycleOwner) { key ->
            binding.apiKeyInput.setText(key)
        }

        binding.changeApiKeyBtn.setOnClickListener {
            Toast.makeText(requireContext(), "Enter your API key", Toast.LENGTH_SHORT).show()
        }

        binding.saveApiKeyBtn.setOnClickListener {
            val newKey = binding.apiKeyInput.text.toString()
            if (newKey.isNotEmpty() && newKey.length >= 20) {
                viewModel.saveApiKey(newKey)
                Toast.makeText(requireContext(), "API Key saved", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Invalid API Key", Toast.LENGTH_SHORT).show()
            }
        }

        setupPermissionToggles()
    }

    private fun setupPermissionToggles() {
        val permissions = listOf(
            Manifest.permission.RECEIVE_SMS to "📨 Receive SMS",
            Manifest.permission.READ_SMS to "📖 Read SMS",
            Manifest.permission.INTERNET to "🌐 Internet"
        )

        for ((permission, name) in permissions) {
            val isGranted = ContextCompat.checkSelfPermission(
                requireContext(),
                permission
            ) == PackageManager.PERMISSION_GRANTED

            val itemView = LinearLayout(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 12, 0, 12)
                }
                orientation = LinearLayout.HORIZONTAL
                setPadding(16, 12, 16, 12)
            }

            val nameView = TextView(requireContext()).apply {
                text = name
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
                textSize = 13f
            }

            val switchView = Switch(requireContext()).apply {
                isChecked = isGranted
                isEnabled = false
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            itemView.addView(nameView)
            itemView.addView(switchView)
            binding.permissionsContainer.addView(itemView)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
