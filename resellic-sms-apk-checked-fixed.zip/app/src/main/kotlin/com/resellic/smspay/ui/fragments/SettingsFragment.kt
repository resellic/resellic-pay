package com.resellic.smspay.ui.fragments

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.resellic.smspay.databinding.FragmentSettingsBinding
import com.resellic.smspay.ui.viewmodels.SettingsViewModel

class SettingsFragment : Fragment() {
    
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Observe API key
        viewModel.apiKey.observe(viewLifecycleOwner) { key ->
            binding.apiKeyInput.setText(key)
        }

        // Setup buttons
        binding.changeApiKeyBtn.setOnClickListener {
            showApiKeyDialog()
        }

        binding.saveApiKeyBtn.setOnClickListener {
            val newKey = binding.apiKeyInput.text.toString()
            if (newKey.isNotEmpty() && newKey.length >= 20) {
                viewModel.saveApiKey(newKey)
                Toast.makeText(requireContext(), "API Key saved", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Invalid API Key", Toast.LENGTH_SHORT).show()
            }
        }

        // Setup permission toggles
        setupPermissionToggles()
    }

    private fun setupPermissionToggles() {
        val permissions = listOf(
            Manifest.permission.RECEIVE_SMS to "Receive SMS",
            Manifest.permission.READ_SMS to "Read SMS",
            Manifest.permission.INTERNET to "Internet"
        )

        for ((permission, name) in permissions) {
            val isGranted = ContextCompat.checkSelfPermission(
                requireContext(),
                permission
            ) == PackageManager.PERMISSION_GRANTED

            // Update toggle state based on permission
            // In a real implementation, you'd have individual toggle views for each permission
        }
    }

    private fun showApiKeyDialog() {
        // In a real implementation, show an AlertDialog to enter API key
        Toast.makeText(requireContext(), "Enter your Resellic Pay API key", Toast.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
