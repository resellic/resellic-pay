# Resellic Pay SMS Forwarder - সম্পূর্ণ সেটআপ গাইড

## ১. প্রাথমিক প্রয়োজনীয়তা

### সফটওয়্যার
- **Android Studio:** 2022.3.1 বা পরবর্তী (Giraffe+)
- **JDK:** 17 বা পরবর্তী
- **Gradle:** 8.1+
- **Android SDK:** 34 (API 34)
- **Minimum SDK:** 24 (Android 7.0+)

### হার্ডওয়্যার
- 4GB RAM সহ কম্পিউটার (8GB সুপারিশকৃত)
- 10GB ফ্রি ডিস্ক স্পেস

## ২. প্রজেক্ট ক্লোন এবং সেটআপ

```bash
# GitHub থেকে ক্লোন করুন
git clone https://github.com/resellic/resellic-sms-android.git
cd resellic-sms-android

# Android Studio তে খুলুন
# File → Open → resellic-sms-android ডিরেক্টরি নির্বাচন করুন
```

## ৩. Gradle Sync এবং Build

```bash
# Android Studio এ সিঙ্ক স্বয়ংক্রিয়ভাবে হবে, অথবা:
./gradlew clean build

# ডিবাগ APK বিল্ড করুন
./gradlew assembleDebug

# রিলিজ APK বিল্ড করুন
./gradlew assembleRelease
```

### Build আউটপুট
- ডিবাগ: `app/build/outputs/apk/debug/app-debug.apk`
- রিলিজ: `app/build/outputs/apk/release/app-release.apk`

## ৪. ডিভাইসে ইনস্টল

### USB কেবল এর মাধ্যমে

```bash
# ডিবাগ APK ইনস্টল করুন
adb install app/build/outputs/apk/debug/app-debug.apk

# রিলিজ APK ইনস্টল করুন (স্বাক্ষরিত)
adb install app/build/outputs/apk/release/app-release.apk
```

### Android Studio থেকে
1. `Run` মেনু → `Run 'app'`
2. ডিভাইস নির্বাচন করুন
3. `OK` ক্লিক করুন

## ৫. প্রথম সেটআপ

### পদক্ষেপ ১: অনুমতি সক্ষম করুন
1. অ্যাপ চালু করুন
2. অনুমতি ডায়ালগ গুলি গ্রহণ করুন:
   - **Receive SMS** ✓
   - **Read SMS** ✓
   - **Battery Optimization** (প্রয়োজন)
   - **Auto Start** (সুপারিশকৃত)

### পদক্ষেপ ২: Settings কনফিগার করুন
1. Settings ট্যাব খুলুন (⚙️)
2. "CHANGE API KEY" বাটন ক্লিক করুন
3. আপনার Resellic Pay API কী দিন
   - API কী ফর্ম্যাট: আপনার 32+ অক্ষরের কী
4. "SAVE API KEY" বাটন ক্লিক করুন
5. সবুজ চেক চিহ্ন দেখা যাবে = সংরক্ষিত ✓

### পদক্ষেপ ৩: Test SMS পাঠান
1. যেকোনো পেমেন্ট প্রোভাইডার থেকে টেস্ট SMS পাঠান
2. Home ট্যাবে নোটিফিকেশন দেখা উচিত
3. SMS Logs ট্যাবে অ্যাক্টিভিটি দেখুন

## ৬. SMS Providers সাপোর্ট

### bKash
```
Sender: bKash
Format: You have received Tk X from [number]. Fee Tk 0.00. Balance Tk Y. TrxID XXXXXXXX
Status: ✓ পার্সিং সাপোর্টেড
```

### Nagad
```
Sender: NAGAD
Format: Money Received. Amount: Tk X Sender: [number] Ref: N/A TxnID: XXXXXXXX
Status: ✓ পার্সিং সাপোর্টেড
```

### BRAC Bank
```
Sender: BRAC-BANK
Format: Your BRAC Bank A/C#XXXX**XXX has been credited by TK X
Status: ✓ পার্সিং সাপোর্টেড (TxnID ছাড়া)
```

### Rocket & Upay
```
Sender: যথাক্রমে
Format: ভিন্ন ফরম্যাট
Status: ✓ পার্সিং সাপোর্টেড
```

## ৭. API ইন্টিগ্রেশন

### SMS Webhook এন্ডপয়েন্ট

অ্যাপটি প্রতিটি SMS এর জন্য এই ফরম্যাটে POST করে:

```json
POST https://pay.resellic.com/api/sms-webhook.php

Headers: {
  "Authorization": "Bearer YOUR_API_KEY",
  "Content-Type": "application/json"
}

Body: {
  "provider": "bKash",
  "txn_id": "ABC123DEF456",
  "amount": 5000.00,
  "sender": "bKash",
  "timestamp": "2026-09-16T10:30:00Z",
  "sms_content": "bKash: You received Tk 5000 from +8801712345678..."
}
```

### সার্ভার রেসপন্স

সফল:
```json
{
  "success": true,
  "status": "received",
  "message": "SMS processed successfully"
}
```

ব্যর্থ:
```json
{
  "success": false,
  "status": "error",
  "message": "Invalid API key"
}
```

## ৮. Retry মেকানিজম

### স্বয়ংক্রিয় Retry লজিক
- **Attempt 1:** 0-5 সেকেন্ড (তাৎক্ষণিক)
- **Attempt 2:** 1 মিনিটে
- **Attempt 3:** 2 মিনিটে
- **Attempt 4:** 5 মিনিটে
- **Attempt 5:** 10 মিনিটে

### Max Retries
- সর্বোচ্চ 5 বার চেষ্টা করা হয়
- তার পরে মার্ক করা হয় "Failed"

### Device Restart সময়
- বুট সম্পন্ন হলে পেন্ডিং SMS স্বয়ংক্রিয়ভাবে রিশিডিউল হয়

## ৯. Notifications

### Incoming SMS
```
💳 bKash Payment
৳5000 - pending
```

### Retry Notification
```
🔄 bKash Retry
৳5000 - Attempt 2/5
```

### Failed Notification
```
✕ bKash Failed
৳5000 - Max retries exceeded
```

## ১০. ট্রাবলশুটিং

### সমস্যা: SMS পাওয়া যাচ্ছে না
**সমাধান:**
1. Settings → অনুমতি চেক করুন
2. SMS পার্সিং লগ দেখুন
3. বার্তা ফরম্যাট সঠিক কিনা যাচাই করুন

```bash
# লগ দেখুন
adb logcat | grep SmsReceiver
```

### সমস্যা: Webhook পাঠানো হচ্ছে না
**সমাধান:**
1. API কী সঠিক কিনা চেক করুন
2. ইন্টারনেট সংযোগ যাচাই করুন
3. সার্ভার লগ দেখুন

```bash
# WorkManager লগ দেখুন
adb logcat | grep SmsForwarder
```

### সমস্যা: অ্যাপ ক্র্যাশ হচ্ছে
**সমাধান:**
1. লগ দেখুন
2. অ্যাপ ডেটা ক্লিয়ার করুন
3. পুনরায় ইনস্টল করুন

```bash
# লগ ক্যাপচার করুন
adb logcat -s ReselicPayApp,SmsReceiver,SmsForwarder,ApiClient

# ডাটা ক্লিয়ার করুন
adb shell pm clear com.resellic.smspay
```

## ১১. নিরাপত্তা সেটআপ

### API কী সুরক্ষা
- API কী কখনো লগ করা হয় না
- অ্যাপে এনক্রিপ্ট করা হয়
- কখনো অন্যদের সাথে শেয়ার করবেন না

### টেকটু্রড প্রোটেকশন
- সব API কল HTTPS
- প্রোগুয়ার্ড সক্ষম (রিলিজ বিল্ড)

## ১२. ডিপ্লয়মেন্ট

### রিলিজ বিল্ড

```bash
# স্বাক্ষরিত রিলিজ APK তৈরি করুন
./gradlew assembleRelease

# APK যাচাই করুন
adb install app/build/outputs/apk/release/app-release.apk
```

### Google Play স্টোর (ভবিষ্যত)
1. Developer অ্যাকাউন্ট তৈরি করুন
2. Signed APK তৈরি করুন
3. Play Console এ আপলোড করুন

## ১३. Development

### মান লাইব্রেরি
- **Retrofit**: 2.10.0 - HTTP Client
- **Room**: 2.6.1 - Local Database
- **WorkManager**: 2.9.0 - Background Tasks
- **Coroutines**: 1.7.3 - Async operations
- **Hilt**: 2.47 - Dependency Injection

### কাস্টম কনফিগুরেশন

`app/build.gradle.kts` এ সম্পাদনা করুন:
```kotlin
defaultConfig {
    applicationId = "com.resellic.smspay"  // প্যাকেজ নাম
    minSdk = 24           // ন্যূনতম SDK
    targetSdk = 34        // টার্গেট SDK
    versionCode = 1       // সংস্করণ কোড
    versionName = "1.0.0" // সংস্করণ নাম
}
```

## ১४. উপযোগী কমান্ড

```bash
# সম্পূর্ণ ক্লিন বিল্ড
./gradlew clean assembleDebug

# ডিবাগ লগ লাইভ দেখুন
adb logcat | grep "resellic\|SmsReceiver\|SmsForwarder"

# অ্যাপ ডাটা ক্লিয়ার করুন
adb shell pm clear com.resellic.smspay

# অ্যাপ আনইনস্টল করুন
adb uninstall com.resellic.smspay

# পারমিশন চেক করুন
adb shell pm list permissions | grep RECEIVE_SMS
```

## ১५. সংস্করণ রিলিজ

নতুন সংস্করণ রিলিজ করতে:

1. সংস্করণ আপডেট করুন
```kotlin
versionCode = 2
versionName = "1.1.0"
```

2. রিলিজ নোটস যোগ করুন
3. টাগ তৈরি করুন
```bash
git tag v1.1.0
git push origin v1.1.0
```

## সাপোর্ট এবং যোগাযোগ

- **Email:** dev@resellic.com
- **Issues:** https://github.com/resellic/resellic-sms-android/issues
- **Website:** https://pay.resellic.com

---

**সর্বশেষ আপডেট:** September 16, 2026
**রক্ষণাবেক্ষণ:** Resellic Dev Team
