// Top-level build.gradle.kts for Resellic SMS Pay Android App

plugins {
    id("com.android.application") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.0" apply false
    id("com.google.dagger.hilt.android") version "2.47" apply false
}

// Define versions
ext {
    set("compose_version", "1.5.0")
    set("kotlin_version", "1.9.0")
    set("android_version", "8.1.0")
    set("gradle_version", "8.1.0")
}

buildscript {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }

    dependencies {
        classpath("com.android.tools.build:gradle:8.1.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.0")
        classpath("com.google.dagger:hilt-android-gradle-plugin:2.47")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
