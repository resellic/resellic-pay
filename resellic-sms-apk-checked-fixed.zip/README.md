# Resellic SMS Pay - Android App

এটি একটি অ্যান্ড্রয়েড অ্যাপ্লিকেশন যা Resellic Pay SMS পেমেন্ট গেটওয়ের সাথে সম্পূর্ণ ইন্টিগ্রেশনে কাজ করে। অ্যাপটি স্বয়ংক্রিয়ভাবে ইনকামিং SMS ক্যাপচার করে এবং https://pay.resellic.com-এ সেগুলি ফরওয়ার্ড করে।

## বৈশিষ্ট্য

### 🏠 Home Screen
- ট্রানজ্যাকশন সাম্মারি (সম্পূর্ণ, পেন্ডিং, ফেইলড)
- সম্প্রতি কার্যকলাপের তালিকা
- সরাসরি SMS স্ক্যান বিকল্প

### 📋 SMS Logs
- সম্পূর্ণ SMS ইতিহাস
- স্ট্যাটাস ফিল্টারিং
- বিস্তারিত লগ বিবরণ

### ⚙️ Settings
- API কী কনফিগারেশন
- অনুমতি ম্যানেজমেন্ট
- অটো-স্টার্ট এবং ব্যাকগ্রাউন্ড সিঙ্ক

## প্রযুক্তিগত বিস্তারিত

### আর্কিটেকচার
- **MVVM** - Model-View-ViewModel প্যাটার্ন
- **Hilt** - ডিপেন্ডেন্সি ইনজেকশন
- **Room** - স্থানীয় ডাটাবেস
- **Retrofit** - HTTP ক্লায়েন্ট
- **WorkManager** - ব্যাকগ্রাউন্ড টাস্ক

### SMS ফরওয়ার্ডিং প্রক্রিয়া

```
Incoming SMS
    ↓
BroadcastReceiver (SmsReceiver)
    ↓
SMS Parser (bKash, Nagad, BRAC Bank)
    ↓
Room Database (SMS সংরক্ষণ)
    ↓
WorkManager (Retry Mechanism)
    ↓
Retrofit API Client
    ↓
POST to /api/sms-webhook.php
    ↓
Resellic Pay Server
```

### Supported SMS Providers
- **bKash** (Personal & Merchant)
- **Nagad** (Personal, Merchant, Bangla QR)
- **BRAC Bank**
- **Upay**
- **Rocket**

## ইনস্টলেশন

### প্রয়োজনীয়তা
- Android 7.0+ (API 24+)
- Android Studio Giraffe 2022.3.1+
- JDK 17+
- Gradle 8.1+

### ধাপ 1: ক্লোন করুন
```bash
git clone https://github.com/resellic/resellic-sms-android.git
cd resellic-sms-android
```

### ধাপ 2: Build করুন
```bash
# ডেবাগ APK
./gradlew build

# রিলিজ APK (স্বাক্ষরিত)
./gradlew assembleRelease
```

### ধাপ 3: ইনস্টল করুন
```bash
# ডেবাগ অ্যাপ্লিকেশন
adb install app/build/outputs/apk/debug/app-debug.apk

# রিলিজ অ্যাপ্লিকেশন
adb install app/build/outputs/apk/release/app-release.apk
```

### ধাপ 4: API কী সেট করুন
1. অ্যাপ খুলুন এবং Settings ট্যাবে যান
2. "CHANGE API KEY" ক্লিক করুন
3. আপনার Resellic Pay API কী দিয়ে এটি সেট করুন
4. "SAVE API KEY" ক্লিক করুন

### ধাপ 5: অনুমতি সক্ষম করুন
- **Receive SMS** - ইনকামিং SMS ক্যাপচার করতে
- **Read SMS** - SMS সামগ্রী পড়তে
- **Battery Optimization** - ব্যাকগ্রাউন্ডে চলতে থাকতে
- **Auto Start** - ডিভাইস বুট করার সময় শুরু করতে

## API ইন্টিগ্রেশন

### SMS Webhook এন্ডপয়েন্ট
```
POST https://pay.resellic.com/api/sms-webhook.php

Headers:
- Content-Type: application/json
- Authorization: Bearer {API_KEY}

Body:
{
  "provider": "bKash",
  "txn_id": "ABC123DEF456",
  "amount": "5000",
  "sender": "bKash",
  "timestamp": "2026-09-16T10:30:00Z",
  "sms_content": "bKash: You received 5000 BDT from +8801712345678..."
}

Response:
{
  "success": true,
  "status": "received",
  "message": "SMS processed successfully"
}
```

## ডাটাবেস স্কিমা

### SMS Entity
```sql
CREATE TABLE sms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,
  transaction_id TEXT UNIQUE,
  amount REAL NOT NULL,
  sender TEXT NOT NULL,
  sms_content TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  retry_count INTEGER DEFAULT 0,
  last_error TEXT,
  webhook_attempts INTEGER DEFAULT 0
);
```

## ট্রাবলশুটিং

### SMS বার্তা পাওয়া যাচ্ছে না?
1. **অনুমতি চেক করুন** - Settings থেকে সব অনুমতি সক্ষম আছে কিনা দেখুন
2. **প্রদানকারী কোড চেক করুন** - SMS সঠিক ফরম্যাটে আছে কিনা নিশ্চিত করুন
3. **লগ দেখুন** - SMS Logs ট্যাবে ত্রুটি বার্তা দেখুন
4. **API কী যাচাই করুন** - Settings থেকে আপনার API কী সঠিক কিনা দেখুন

### Webhook পাঠানো হচ্ছে না?
1. **ইন্টারনেট সংযোগ চেক করুন**
2. **API এন্ডপয়েন্ট যাচাই করুন** - https://pay.resellic.com/api/sms-webhook.php অ্যাক্সেসযোগ্য
3. **সার্ভার লগ দেখুন** - Resellic Pay সার্ভার লগ চেক করুন

### অ্যাপ ক্র্যাশ হচ্ছে?
1. **লগ দেখুন** - `adb logcat | grep resellic`
2. **Room ডাটাবেস রিসেট করুন** - App Settings → Storage → Clear Data
3. **সর্বশেষ সংস্করণ আপডেট করুন**

## ডেভেলপমেন্ট

### প্রজেক্ট স্ট্রাকচার
```
resellic-sms-android/
├── app/
│   ├── src/main/
│   │   ├── kotlin/com/resellic/smspay/
│   │   │   ├── ui/
│   │   │   │   ├── fragments/
│   │   │   │   └── viewmodels/
│   │   │   ├── data/
│   │   │   │   ├── local/ (Room DB)
│   │   │   │   └── remote/ (Retrofit)
│   │   │   ├── worker/ (WorkManager)
│   │   │   └── utils/
│   │   └── res/
│   │       ├── layout/
│   │       ├── drawable/
│   │       └── values/
│   └── build.gradle.kts
├── build.gradle.kts
└── README.md
```

### প্রধান ফাইলগুলি
- `SmsReceiver.kt` - Broadcast receiver SMS ক্যাপচার করতে
- `SmsParser.kt` - SMS পার্সিং লজিক
- `ApiClient.kt` - Retrofit সেটআপ
- `SmsForwarderWorker.kt` - WorkManager retry লজিক
- `HomeFragment.kt`, `LogsFragment.kt`, `SettingsFragment.kt` - UI

## নিরাপত্তা

### নিরাপত্তা ব্যবস্থা
1. **API কী এনক্রিপশন** - SharedPreferences এনক্রিপশন
2. **HTTPS শুধুমাত্র** - সব API কল HTTPS
3. **ProGuard** - কোড মিনিফিকেশন
4. **পারমিশন ভেরিফিকেশন** - Runtime পারমিশন চেক

### সংবেদনশীল ডেটা
- API কী কখনো লগ করা হয় না
- SMS সামগ্রী শুধুমাত্র লোকালি সংরক্ষণ করা হয়
- সার্ভারে কোনো ব্যক্তিগত তথ্য সংরক্ষণ করা হয় না (শুধুমাত্র ট্রানজ্যাকশন ডেটা)

## লাইসেন্স

**Proprietary** - Resellic Pay দ্বারা সংরক্ষিত

## সাপোর্ট

সমস্যা বা প্রশ্নের জন্য:
- Email: support@resellic.com
- Website: https://pay.resellic.com

## পরিবর্তন লগ

### v1.0.0 (Initial Release)
- Home, Logs, Settings স্ক্রিন
- SMS পার্সিং এবং ফরওয়ার্ডিং
- Webhook retry mechanism
- অটো-স্টার্ট এবং ব্যাকগ্রাউন্ড সিঙ্ক
