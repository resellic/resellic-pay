package com.biswasto.pay

import android.app.Application
import com.biswasto.pay.data.Prefs
import com.biswasto.pay.data.Store
import com.biswasto.pay.sms.Notifier
import com.biswasto.pay.sms.Scheduler

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Store.init(this)
        Notifier.createChannels(this)
        Scheduler.schedulePeriodicScan(this)
    }
}
