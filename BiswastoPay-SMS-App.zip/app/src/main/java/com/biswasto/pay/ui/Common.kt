package com.biswasto.pay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.biswasto.pay.data.Status
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun money(a: Double?): String = if (a == null) "—" else "৳" + String.format(Locale.US, "%,.2f", a)
fun timeFmt(ts: Long): String = SimpleDateFormat("d MMM, h:mm a", Locale.US).format(Date(ts))
fun shortTime(ts: Long): String = SimpleDateFormat("h:mm a", Locale.US).format(Date(ts))

/** White card with a gradient title bar, like the Settings reference design. */
@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    badge: (@Composable RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(8.dp, shape, ambientColor = C.P1.copy(alpha = .25f), spotColor = C.P1.copy(alpha = .25f))
            .clip(shape)
            .background(Color.White)
    ) {
        Row(
            Modifier.fillMaxWidth().background(C.Grad).padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (badge != null) Row(content = badge)
        }
        content()
    }
}

@Composable
fun Pill(text: String, fg: Color, bg: Color, small: Boolean = false) {
    Text(
        text,
        color = fg,
        fontSize = if (small) 10.5.sp else 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(horizontal = if (small) 9.dp else 11.dp, vertical = if (small) 2.dp else 4.dp)
    )
}

fun statusColors(s: Status): Pair<Color, Color> = when (s) {
    Status.COMPLETED -> C.GreenDark to C.GreenBg
    Status.PENDING -> C.Orange to C.OrangeBg
    Status.FAILED -> C.Red to C.RedBg
    Status.IGNORED -> C.Muted to C.GrayBg
}

fun statusLabel(s: Status) = when (s) {
    Status.COMPLETED -> "Completed"
    Status.PENDING -> "Pending"
    Status.FAILED -> "Failed"
    Status.IGNORED -> "Ignored"
}

@Composable
fun BrandSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = C.Green,
            checkedBorderColor = C.Green,
            uncheckedThumbColor = Color.White,
            uncheckedTrackColor = C.Gray,
            uncheckedBorderColor = C.Gray
        )
    )
}
