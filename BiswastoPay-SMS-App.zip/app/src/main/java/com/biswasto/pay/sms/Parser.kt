package com.biswasto.pay.sms

/**
 * Strict sender check: only these SMS sender IDs are forwarded.
 * A fake sender such as "NAGAD-BD" or a phone number never matches.
 */
object Parser {
    private val EXACT = mapOf(
        "bkash" to "bKash",
        "nagad" to "Nagad",
        "16216" to "Rocket",
        "rocket" to "Rocket",
        "upay" to "Upay",
        "brac" to "BRAC Bank",
        "bracbank" to "BRAC Bank",
        "sbl" to "Sonali Bank",
        "sonalibank" to "Sonali Bank",
        "sonali" to "Sonali Bank"
    )

    /** Returns the provider name, or null if the sender is not an allowed payment sender. */
    fun provider(sender: String): String? = EXACT[sender.trim().lowercase()]

    private val AMT1 = Regex("""(?:BDT|Tk\.?|৳)\s*([0-9,]+(?:\.[0-9]{1,4})?)""", RegexOption.IGNORE_CASE)
    private val AMT2 = Regex("""([0-9,]+(?:\.[0-9]{1,4})?)\s*(?:BDT|Tk\.?|Taka)""", RegexOption.IGNORE_CASE)
    private val TRX = Regex("""(?:TrxID|TxnID|TxnId|Trx|Transaction ID)[:\s#]*([A-Z0-9]{6,20})""", RegexOption.IGNORE_CASE)
    private val PHONE = Regex("""(?<!\d)(01\d{9})(?!\d)""")
    private val ACC = Regex("""A/C:?\s*([*\dX]{4,})""", RegexOption.IGNORE_CASE)

    fun amount(body: String): Double? {
        val m = AMT1.find(body) ?: AMT2.find(body) ?: return null
        return m.groupValues[1].replace(",", "").toDoubleOrNull()?.takeIf { it > 0.0 }
    }

    fun trx(body: String): String? = TRX.find(body)?.groupValues?.get(1)?.uppercase()

    fun phone(body: String): String? =
        PHONE.find(body)?.groupValues?.get(1) ?: ACC.find(body)?.groupValues?.get(1)?.let { "A/C $it" }
}
