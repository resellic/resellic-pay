package com.biswasto.pay.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class Status { PENDING, COMPLETED, FAILED, IGNORED }

data class SmsRecord(
    val id: String,
    val sender: String,
    val body: String,
    val receivedAt: Long,
    val provider: String,
    val amount: Double?,
    val trx: String?,
    val phone: String?,
    val status: Status,
    val reason: String,
    val webhookAt: Long?
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("sender", sender); put("body", body); put("receivedAt", receivedAt)
        put("provider", provider); put("amount", amount ?: JSONObject.NULL); put("trx", trx ?: JSONObject.NULL)
        put("phone", phone ?: JSONObject.NULL); put("status", status.name); put("reason", reason)
        put("webhookAt", webhookAt ?: JSONObject.NULL)
    }

    companion object {
        fun fromJson(o: JSONObject) = SmsRecord(
            id = o.getString("id"),
            sender = o.getString("sender"),
            body = o.getString("body"),
            receivedAt = o.getLong("receivedAt"),
            provider = o.getString("provider"),
            amount = if (o.isNull("amount")) null else o.getDouble("amount"),
            trx = if (o.isNull("trx")) null else o.getString("trx"),
            phone = if (o.isNull("phone")) null else o.getString("phone"),
            status = runCatching { Status.valueOf(o.getString("status")) }.getOrDefault(Status.PENDING),
            reason = o.optString("reason"),
            webhookAt = if (o.isNull("webhookAt")) null else o.getLong("webhookAt")
        )
    }
}

/** Small JSON-file store. Keeps the latest 500 payment SMS. */
object Store {
    private const val MAX = 500
    private lateinit var file: File
    private val lock = Any()
    private val _items = MutableStateFlow<List<SmsRecord>>(emptyList())
    val items: StateFlow<List<SmsRecord>> = _items.asStateFlow()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "sms_records.json")
        synchronized(lock) {
            _items.value = runCatching {
                val arr = JSONArray(file.readText())
                (0 until arr.length()).map { SmsRecord.fromJson(arr.getJSONObject(it)) }
            }.getOrDefault(emptyList())
        }
    }

    /** Returns false when the SMS was already stored. */
    fun add(r: SmsRecord): Boolean = synchronized(lock) {
        if (_items.value.any { it.id == r.id }) return false
        _items.value = (listOf(r) + _items.value).sortedByDescending { it.receivedAt }.take(MAX)
        persist()
        true
    }

    fun update(id: String, f: (SmsRecord) -> SmsRecord) = synchronized(lock) {
        _items.value = _items.value.map { if (it.id == id) f(it) else it }
        persist()
    }

    fun pending(): List<SmsRecord> = _items.value.filter { it.status == Status.PENDING }

    private fun persist() {
        val arr = JSONArray()
        _items.value.forEach { arr.put(it.toJson()) }
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }
}
