package com.biswasto.pay.sms

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Telephony
import androidx.core.content.ContextCompat
import com.biswasto.pay.data.Prefs

/** Reads the SMS inbox and captures payment SMS not seen yet (e.g. received while the app was killed). */
object InboxScanner {
    private const val FIRST_SCAN_WINDOW = 24L * 60 * 60 * 1000 // first scan looks back 24h

    fun scan(ctx: Context): Int {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return 0
        val now = System.currentTimeMillis()
        val since = Prefs.lastScanAt.takeIf { it > 0 }?.minus(10 * 60 * 1000) ?: (now - FIRST_SCAN_WINDOW)
        var found = 0
        ctx.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            "${Telephony.Sms.DATE} >= ?",
            arrayOf(since.toString()),
            "${Telephony.Sms.DATE} ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val addr = c.getString(0) ?: continue
                val body = c.getString(1) ?: continue
                if (Ingest.capture(ctx, addr, body, c.getLong(2))) found++
            }
        }
        Prefs.lastScanAt = now
        return found
    }
}
