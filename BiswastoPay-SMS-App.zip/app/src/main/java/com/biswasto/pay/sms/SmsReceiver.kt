package com.biswasto.pay.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (parts.isEmpty()) return
        // Multi-part SMS arrive as several parts from the same sender: join them.
        parts.groupBy { it.displayOriginatingAddress ?: "" }.forEach { (sender, msgs) ->
            val body = msgs.joinToString("") { it.displayMessageBody ?: "" }
            val ts = msgs.first().timestampMillis.takeIf { it > 0 } ?: System.currentTimeMillis()
            Ingest.capture(ctx, sender, body, ts)
        }
    }
}
