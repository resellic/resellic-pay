package com.biswasto.pay.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.biswasto.pay.data.Prefs
import com.biswasto.pay.sms.Api
import com.biswasto.pay.sms.Scheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

private fun openAppSettings(ctx: Context) {
    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun mask(t: String) = if (t.length <= 8) t else t.take(4) + " ············ " + t.takeLast(4)

@Composable
fun SettingsScreen(resumeTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val token by Prefs.token.collectAsState()
    val active by Prefs.active.collectAsState()
    val autoStart by Prefs.autoStart.collectAsState()

    var editing by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // text, isError
    var tick by remember { mutableStateOf(0) }
    val t = tick + resumeTick // re-read system permission state after returning to the app

    val smsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        tick++
        if (res.values.any { !it }) openAppSettings(ctx)
        else { Scheduler.scanNow(ctx); Scheduler.syncNow(ctx) }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        tick++
        if (!ok) openAppSettings(ctx)
    }

    val receiveOk = t >= 0 && granted(ctx, Manifest.permission.RECEIVE_SMS)
    val readOk = t >= 0 && granted(ctx, Manifest.permission.READ_SMS)
    val notifOk = t >= 0 && NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val batteryOk = t >= 0 && pm.isIgnoringBatteryOptimizations(ctx.packageName)
    val grantedCount = listOf(receiveOk, readOk, notifOk, batteryOk, autoStart).count { it }

    fun save() {
        val newToken = input.trim()
        if (newToken.isEmpty()) { msg = "Enter the device token from biswasto.com → Devices" to true; return }
        busy = true; msg = null
        scope.launch {
            val res = withContext(Dispatchers.IO) { Api.verifyToken(newToken) }
            busy = false
            when (res) {
                is Api.Result.Ok -> {
                    Prefs.saveToken(newToken); Prefs.setActive(true)
                    editing = false; input = ""
                    msg = "Token saved · Active" to false
                    Scheduler.scanNow(ctx); Scheduler.syncNow(ctx)
                }
                is Api.Result.BadToken -> { Prefs.setActive(false); msg = "Invalid token — check it on biswasto.com" to true }
                is Api.Result.Error -> msg = "Could not connect: ${res.message}" to true
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionCard("API Configuration", badge = {
            if (active) Pill("Connected", C.GreenDark, C.GreenBg) else Pill("Not connected", C.Red, C.RedBg)
        }) {
            Column(Modifier.padding(16.dp)) {
                Text("One token for all payment methods", color = C.Muted, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                if (editing) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        singleLine = true, placeholder = { Text("Paste device token") },
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = C.Ink),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.P1, unfocusedBorderColor = C.P2, cursorColor = C.P1),
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Text(
                        if (token.isBlank()) "No token — tap Change Token" else mask(token),
                        color = C.P1, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Lav)
                            .border(1.5.dp, C.P2.copy(alpha = .6f), RoundedCornerShape(14.dp)).padding(14.dp)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(C.Lav)
                            .clickable { editing = !editing; input = ""; msg = null }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(if (editing) "Cancel" else "Change Token", color = C.P1, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(C.Grad)
                            .clickable(enabled = !busy) {
                                if (editing) save() else if (token.isNotBlank()) { input = token; save() }
                                else msg = "Tap Change Token and paste your token first" to true
                            }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (busy) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.height(18.dp).width(18.dp))
                        else Text("Save Token", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                msg?.let { (text, err) ->
                    Spacer(Modifier.height(10.dp))
                    Text(text, color = if (err) C.Red else C.GreenDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        SectionCard("Permissions", badge = {
            if (grantedCount == 5) Pill("5/5 Granted", C.GreenDark, C.GreenBg) else Pill("$grantedCount/5 Granted", C.Red, C.RedBg)
        }) {
            PermRow("Receive SMS", "Allow app to receive incoming payment SMS", receiveOk) {
                if (receiveOk) openAppSettings(ctx) else smsLauncher.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS))
            }
            HorizontalDivider(color = C.Border)
            PermRow("Read SMS", "Allow app to scan the inbox for missed SMS", readOk) {
                if (readOk) openAppSettings(ctx) else smsLauncher.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS))
            }
            HorizontalDivider(color = C.Border)
            PermRow("Notifications", "Alert when a payment is completed or failed", notifOk) {
                if (!notifOk && Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else openAppSettings(ctx)
            }
            HorizontalDivider(color = C.Border)
            PermRow("Battery Optimization", "Allow app to stay active during sync", batteryOk) {
                val i = if (batteryOk) Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        else Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure { openAppSettings(ctx) }
                tick++
            }
            HorizontalDivider(color = C.Border)
            PermRow("Auto Start", "Start scanning automatically after phone restarts", autoStart) {
                Prefs.setAutoStart(!autoStart)
                if (!autoStart) Scheduler.schedulePeriodicScan(ctx)
            }
        }

        Text("Server: ${Api.ENDPOINT}", color = C.Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun PermRow(title: String, sub: String, on: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, color = C.Muted, fontSize = 11.5.sp)
        }
        Spacer(Modifier.width(10.dp))
        BrandSwitch(on) { onToggle() }
    }
}
