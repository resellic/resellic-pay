package com.biswasto.pay.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.biswasto.pay.R
import com.biswasto.pay.data.Prefs

@Composable
fun AppRoot(openSmsId: String?, onSmsOpened: () -> Unit, resumeTick: Int) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val active by Prefs.active.collectAsState()

    Column(Modifier.fillMaxSize().background(C.Bg)) {
        Header(active)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> HomeScreen(openSmsId, onSmsOpened, resumeTick)
                1 -> StatsScreen()
                else -> SettingsScreen(resumeTick)
            }
        }
        BottomBar(tab) { tab = it }
    }
}

@Composable
private fun Header(active: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(C.Grad).statusBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.logo_white), contentDescription = "Biswasto Pay", modifier = Modifier.size(36.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Biswasto Pay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, maxLines = 1)
            Text("SMS Payment Verification", color = Color.White.copy(alpha = .85f), fontSize = 11.5.sp, maxLines = 1)
        }
        Row(
            Modifier.clip(RoundedCornerShape(20.dp)).background(if (active) C.GreenBg else C.RedBg)
                .padding(horizontal = 11.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(if (active) C.Green else C.Red))
            Spacer(Modifier.width(6.dp))
            Text(if (active) "Active" else "Inactive", color = if (active) C.GreenDark else C.Red,
                fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(C.Grad).navigationBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        listOf("Home", "Stats", "Settings").forEachIndexed { i, label ->
            val on = tab == i
            val tint = if (on) Color.White else Color.White.copy(alpha = .7f)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .background(if (on) Color.White.copy(alpha = .2f) else Color.Transparent)
                    .clickable { onTab(i) }.padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (i) {
                    0 -> Icon(Icons.Filled.Home, null, tint = tint, modifier = Modifier.size(22.dp))
                    1 -> StatsIcon(tint)
                    else -> Icon(Icons.Filled.Settings, null, tint = tint, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.height(3.dp))
                Text(label, color = tint, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun StatsIcon(tint: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height; val bw = w * .18f
        listOf(.45f, .85f, .62f).forEachIndexed { i, f ->
            val x = w * (.12f + i * .3f)
            drawRoundRect(tint, Offset(x, h * (.92f - f * .8f)), Size(bw, h * f * .8f), CornerRadius(bw / 2))
        }
    }
}
