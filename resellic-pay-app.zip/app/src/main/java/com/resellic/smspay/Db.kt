package com.resellic.smspay

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

object Status {
    const val PENDING = "pending"
    const val COMPLETED = "completed"
    const val UNMATCHED = "unmatched"
    const val FAILED = "failed"
}

data class SmsRecord(
    val id: Long,
    val label: String,
    val key: String,
    val address: String,
    val amount: Double,
    val txn: String?,
    val fromNumber: String?,
    val body: String,
    val receivedAt: Long,
    val status: String,
    val attempts: Int,
    val lastError: String?,
    val nextRetryAt: Long,
    val sentAt: Long
)

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "resellic_pay.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sms (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "provider_label TEXT NOT NULL, " +
                "provider_key TEXT NOT NULL, " +
                "address TEXT NOT NULL, " +
                "amount REAL NOT NULL, " +
                "txn TEXT, " +
                "from_number TEXT, " +
                "body TEXT NOT NULL, " +
                "received_at INTEGER NOT NULL, " +
                "status TEXT NOT NULL, " +
                "attempts INTEGER NOT NULL DEFAULT 0, " +
                "last_error TEXT, " +
                "next_retry_at INTEGER NOT NULL DEFAULT 0, " +
                "sent_at INTEGER NOT NULL DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(p: Parsed, address: String, body: String, receivedAt: Long): Long {
        val v = ContentValues()
        v.put("provider_label", p.label)
        v.put("provider_key", p.key)
        v.put("address", address)
        v.put("amount", p.amount)
        v.put("txn", p.txn)
        v.put("from_number", p.fromNumber)
        v.put("body", body)
        v.put("received_at", receivedAt)
        v.put("status", Status.PENDING)
        return writableDatabase.insert("sms", null, v)
    }

    fun existsBody(body: String): Boolean {
        return readableDatabase.rawQuery("SELECT 1 FROM sms WHERE body = ? LIMIT 1", arrayOf(body)).use {
            it.moveToFirst()
        }
    }

    fun get(id: Long): SmsRecord? {
        return readableDatabase.rawQuery("SELECT * FROM sms WHERE id = ?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) row(it) else null
        }
    }

    fun list(limit: Int): List<SmsRecord> {
        val out = ArrayList<SmsRecord>()
        readableDatabase.rawQuery(
            "SELECT * FROM sms ORDER BY received_at DESC, id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use {
            while (it.moveToNext()) out.add(row(it))
        }
        return out
    }

    fun pending(): List<SmsRecord> {
        val out = ArrayList<SmsRecord>()
        readableDatabase.rawQuery(
            "SELECT * FROM sms WHERE status = ? ORDER BY id ASC",
            arrayOf(Status.PENDING)
        ).use {
            while (it.moveToNext()) out.add(row(it))
        }
        return out
    }

    fun count(status: String): Int {
        return readableDatabase.rawQuery("SELECT COUNT(*) FROM sms WHERE status = ?", arrayOf(status)).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun update(id: Long, status: String, attempts: Int, lastError: String?, nextRetryAt: Long, sentAt: Long) {
        val v = ContentValues()
        v.put("status", status)
        v.put("attempts", attempts)
        v.put("last_error", lastError)
        v.put("next_retry_at", nextRetryAt)
        v.put("sent_at", sentAt)
        writableDatabase.update("sms", v, "id = ?", arrayOf(id.toString()))
    }

    private fun row(c: Cursor): SmsRecord {
        fun str(name: String): String? {
            val i = c.getColumnIndexOrThrow(name)
            return if (c.isNull(i)) null else c.getString(i)
        }
        return SmsRecord(
            id = c.getLong(c.getColumnIndexOrThrow("id")),
            label = str("provider_label") ?: "",
            key = str("provider_key") ?: "",
            address = str("address") ?: "",
            amount = c.getDouble(c.getColumnIndexOrThrow("amount")),
            txn = str("txn"),
            fromNumber = str("from_number"),
            body = str("body") ?: "",
            receivedAt = c.getLong(c.getColumnIndexOrThrow("received_at")),
            status = str("status") ?: Status.PENDING,
            attempts = c.getInt(c.getColumnIndexOrThrow("attempts")),
            lastError = str("last_error"),
            nextRetryAt = c.getLong(c.getColumnIndexOrThrow("next_retry_at")),
            sentAt = c.getLong(c.getColumnIndexOrThrow("sent_at"))
        )
    }

    companion object {
        @Volatile
        private var instance: Db? = null

        fun get(ctx: Context): Db {
            return instance ?: synchronized(this) {
                instance ?: Db(ctx.applicationContext).also { instance = it }
            }
        }
    }
}
