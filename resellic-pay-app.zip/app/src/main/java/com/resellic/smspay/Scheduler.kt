package com.resellic.smspay

import android.content.Context
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

object Scheduler {
    private fun network() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    /** Send as soon as a network is available. */
    fun now(ctx: Context, id: Long) {
        val wm = WorkManager.getInstance(ctx)
        wm.cancelAllWorkByTag("sms-$id")
        val req = OneTimeWorkRequestBuilder<SendWorker>()
            .setInputData(workDataOf("id" to id))
            .setConstraints(network())
            .addTag("sms-$id")
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        wm.enqueue(req)
    }

    /** Send again after [minutes]. */
    fun later(ctx: Context, id: Long, minutes: Long) {
        val req = OneTimeWorkRequestBuilder<SendWorker>()
            .setInputData(workDataOf("id" to id))
            .setConstraints(network())
            .addTag("sms-$id")
            .setInitialDelay(minutes, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(ctx).enqueue(req)
    }
}
