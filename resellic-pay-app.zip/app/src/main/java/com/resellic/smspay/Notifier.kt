package com.resellic.smspay

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.Notification

object Notifier {
    private const val CHANNEL = "payments"

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, "Payments", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Payment SMS sent to the server"
        nm.createNotificationChannel(ch)
    }

    private fun show(ctx: Context, id: Long, title: String, text: String, icon: Int) {
        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id.toInt(), n)
    }

    private fun money(a: Double) = "৳" + String.format(java.util.Locale.US, "%.2f", a)

    fun sent(ctx: Context, r: SmsRecord) {
        val txn = if (r.txn.isNullOrBlank()) "" else " · ${r.txn}"
        show(ctx, r.id, "${r.label} · Sent to server", "${money(r.amount)}$txn", R.drawable.ic_check)
    }

    fun failed(ctx: Context, r: SmsRecord, error: String) {
        show(ctx, r.id, "${r.label} · Failed to send", "${money(r.amount)} · $error", R.drawable.ic_close)
    }

    fun unmatched(ctx: Context, r: SmsRecord) {
        show(ctx, r.id, "${r.label} · No matching order", "${money(r.amount)} · Admin panel থেকে মিলিয়ে দিন", R.drawable.ic_clock)
    }
}
