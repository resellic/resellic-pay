package com.resellic.smspay

import android.content.Context

object Ingest {
    /**
     * Parses an SMS and, if it is a supported payment SMS, stores it and queues it for sending.
     * Returns the new record id, or -1 when the SMS was ignored.
     */
    fun handle(ctx: Context, address: String, body: String, receivedAt: Long, skipIfKnown: Boolean): Long {
        val parsed = SmsParser.parse(address, body) ?: return -1L
        val db = Db.get(ctx)
        if (skipIfKnown && db.existsBody(body)) return -1L
        val id = db.insert(parsed, address, body, receivedAt)
        if (id > 0) Scheduler.now(ctx, id)
        return id
    }
}
