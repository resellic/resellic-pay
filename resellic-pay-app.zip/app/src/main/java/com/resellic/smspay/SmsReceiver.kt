package com.resellic.smspay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages == null || messages.isEmpty()) return

        val address = messages[0].originatingAddress ?: return
        val body = messages.joinToString("") { it.messageBody ?: "" }
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                Ingest.handle(app, address, body, System.currentTimeMillis(), false)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
