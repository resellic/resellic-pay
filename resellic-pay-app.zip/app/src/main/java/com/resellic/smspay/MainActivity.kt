package com.resellic.smspay

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.provider.Telephony
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private class DetailRow(val label: String, val value: String, val color: Int)

class MainActivity : Activity() {

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private val cBlue1 = Color.parseColor("#1E40AF")
    private val cBlue2 = Color.parseColor("#1D4ED8")
    private val cDark = Color.parseColor("#0F172A")
    private val cGray = Color.parseColor("#475569")
    private val cLine = Color.parseColor("#E2E8F0")

    private lateinit var content: FrameLayout
    private lateinit var pill: LinearLayout
    private lateinit var pillDot: View
    private lateinit var pillText: TextView
    private val tabs = ArrayList<LinearLayout>()

    private var tab = 0
    private var serverOk = false
    private var tickCount = 0
    private var lastSig = ""

    private var listBox: LinearLayout? = null
    private var countDone: TextView? = null
    private var countPending: TextView? = null
    private var countFailed: TextView? = null

    private val permSwitches = ArrayList<Switch>()
    private var permBadge: TextView? = null
    private var suppressToggle = false
    private var tokenField: EditText? = null
    private var editingToken = false

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (tab != 2) renderData()
            tickCount++
            if (tickCount % 10 == 0) checkServer()
            handler.postDelayed(this, 3000L)
        }
    }

    private companion object {
        const val RC_AUTO = 1
        const val RC_TOGGLE = 2
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#F1F5F9"))

        val header = buildHeader()
        content = FrameLayout(this)
        val footer = buildFooter()

        root.addView(header, lpL(match, wrap))
        root.addView(content, lpL(match, 0, 1f))
        root.addView(footer, lpL(match, wrap))

        root.setOnApplyWindowInsetsListener { _, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            val keyboard = ime.bottom > bars.bottom
            header.setPadding(dp(20), dp(22) + bars.top, dp(20), dp(18))
            footer.setPadding(dp(8), dp(6), dp(8), dp(10) + (if (keyboard) 0 else bars.bottom))
            root.setPadding(0, 0, 0, if (keyboard) ime.bottom else 0)
            insets
        }
        setContentView(root)

        showTab(0)

        if (savedInstanceState == null) {
            val need = ArrayList<String>()
            if (!hasPerm(Manifest.permission.RECEIVE_SMS)) need.add(Manifest.permission.RECEIVE_SMS)
            if (!hasPerm(Manifest.permission.READ_SMS)) need.add(Manifest.permission.READ_SMS)
            if (!hasPerm(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
            if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), RC_AUTO)
        }
    }

    override fun onResume() {
        super.onResume()
        renderData()
        refreshPerms()
        checkServer()
        handler.postDelayed(tick, 3000L)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
        if (requestCode == RC_TOGGLE && grantResults.isNotEmpty() && permissions.isNotEmpty() &&
            grantResults[0] != PackageManager.PERMISSION_GRANTED &&
            !shouldShowRequestPermissionRationale(permissions[0])
        ) {
            openAppSettings()
        }
    }

    // ---------------------------------------------------------------- header / footer

    private fun buildHeader(): LinearLayout {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.background = gradient()
        h.setPadding(dp(20), dp(22), dp(20), dp(18))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        h.addView(logo, lpL(dp(56), dp(44)))

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(tv("Resellic Pay", 20f, Color.WHITE, true), lpL(wrap, wrap))
        titles.addView(tv("SMS based processing", 12f, Color.parseColor("#DBEAFE"), false), lpL(wrap, wrap))
        val titlesLp = lpL(0, wrap, 1f)
        titlesLp.marginStart = dp(12)
        h.addView(titles, titlesLp)

        pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(12), dp(6), dp(12), dp(6))
        pillDot = View(this)
        pillText = tv("Inactive", 12f, Color.parseColor("#334155"), true)
        val dotLp = lpL(dp(8), dp(8))
        dotLp.marginEnd = dp(6)
        pill.addView(pillDot, dotLp)
        pill.addView(pillText, lpL(wrap, wrap))
        h.addView(pill, lpL(wrap, wrap))
        updatePill()
        return h
    }

    private fun updatePill() {
        val active = serverOk && Config.token(this).isNotBlank()
        pill.background = rounded(Color.parseColor(if (active) "#DCFCE7" else "#E2E8F0"), 999)
        val dot = GradientDrawable()
        dot.shape = GradientDrawable.OVAL
        dot.setColor(Color.parseColor(if (active) "#16A34A" else "#64748B"))
        pillDot.background = dot
        pillText.text = if (active) "Active" else "Inactive"
        pillText.setTextColor(Color.parseColor(if (active) "#166534" else "#334155"))
    }

    private fun buildFooter(): LinearLayout {
        val f = LinearLayout(this)
        f.orientation = LinearLayout.HORIZONTAL
        f.background = gradient()
        f.setPadding(dp(8), dp(6), dp(8), dp(10))
        tabs.clear()

        val icons = intArrayOf(R.drawable.ic_home, R.drawable.ic_logs, R.drawable.ic_settings)
        val names = arrayOf("Home", "Logs", "Settings")
        for (i in 0..2) {
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER
            t.minimumHeight = dp(52)
            t.contentDescription = names[i]
            t.isClickable = true
            t.setOnClickListener { showTab(i) }

            val iv = ImageView(this)
            iv.setImageResource(icons[i])
            iv.imageTintList = ColorStateList.valueOf(Color.WHITE)
            t.addView(iv, lpL(dp(22), dp(22)))

            val label = tv(names[i], 12f, Color.WHITE, true)
            label.gravity = Gravity.CENTER
            val labelLp = lpL(wrap, wrap)
            labelLp.topMargin = dp(3)
            t.addView(label, labelLp)

            f.addView(t, lpL(0, wrap, 1f))
            tabs.add(t)
        }
        return f
    }

    private fun styleTabs() {
        for (i in tabs.indices) {
            if (i == tab) {
                tabs[i].background = rounded(Color.parseColor("#2EFFFFFF"), 12)
            } else {
                tabs[i].background = null
            }
        }
    }

    private fun showTab(i: Int) {
        tab = i
        lastSig = ""
        listBox = null
        countDone = null
        countPending = null
        countFailed = null
        permSwitches.clear()
        permBadge = null
        tokenField = null
        editingToken = false

        content.removeAllViews()
        val v = when (i) {
            0 -> buildListScreen("Recent Activity", true)
            1 -> buildListScreen("SMS Logs", false)
            else -> buildSettings()
        }
        content.addView(v, FrameLayout.LayoutParams(match, match))
        styleTabs()
        if (i == 2) refreshPerms() else renderData()
    }

    // ---------------------------------------------------------------- Home / Logs

    private fun buildListScreen(title: String, home: Boolean): View {
        val screen = LinearLayout(this)
        screen.orientation = LinearLayout.VERTICAL
        screen.setPadding(dp(16), dp(16), dp(16), dp(16))

        if (home) {
            val sum = LinearLayout(this)
            sum.orientation = LinearLayout.HORIZONTAL
            sum.background = rounded(Color.WHITE, 14, cLine)
            sum.setPadding(dp(8), dp(14), dp(8), dp(14))
            countDone = countCell(sum, "Completed", "#15803D", false)
            countPending = countCell(sum, "Pending", "#C2410C", true)
            countFailed = countCell(sum, "Failed", "#B91C1C", true)
            val sumLp = lpL(match, wrap)
            sumLp.bottomMargin = dp(12)
            screen.addView(sum, sumLp)
        }

        var scanBtn: View? = null
        if (home) {
            val b = button("Scan", cBlue1, Color.WHITE)
            b.setOnClickListener { scanInbox() }
            scanBtn = b
        }
        val card = card(title, scanBtn)

        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list)
        card.addView(scroll, lpL(match, 0, 1f))
        listBox = list

        screen.addView(card, lpL(match, 0, 1f))
        return screen
    }

    private fun countCell(parent: LinearLayout, label: String, color: String, dividerBefore: Boolean): TextView {
        if (dividerBefore) parent.addView(divider(), lpL(dp(1), match))
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER
        val n = tv("0", 26f, Color.parseColor(color), true)
        n.gravity = Gravity.CENTER
        val l = tv(label, 12f, cGray, true)
        l.gravity = Gravity.CENTER
        cell.addView(n, lpL(wrap, wrap))
        cell.addView(l, lpL(wrap, wrap))
        parent.addView(cell, lpL(0, wrap, 1f))
        return n
    }

    private fun renderData() {
        val box = listBox ?: return
        val db = Db.get(this)
        val recs = db.list(if (tab == 0) 100 else 500)
        val sig = recs.joinToString("|") { "${it.id}:${it.status}:${it.attempts}" }
        if (sig == lastSig) return
        lastSig = sig

        box.removeAllViews()
        if (recs.isEmpty()) {
            val e = tv("No payment SMS yet", 14f, cGray, false)
            e.gravity = Gravity.CENTER
            e.setPadding(dp(16), dp(40), dp(16), dp(40))
            box.addView(e, lpL(match, wrap))
        }
        for (r in recs) {
            box.addView(rowView(r), lpL(match, wrap))
            box.addView(divider(), lpL(match, dp(1)))
        }
        countDone?.text = db.count(Status.COMPLETED).toString()
        countPending?.text = db.count(Status.PENDING).toString()
        countFailed?.text = db.count(Status.FAILED).toString()
    }

    private fun rowView(r: SmsRecord): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        row.minimumHeight = dp(68)
        row.background = ripple(Color.WHITE)
        row.isClickable = true
        row.setOnClickListener { showDetails(r) }

        val icon = FrameLayout(this)
        icon.background = rounded(bgOf(r.status), 10)
        val iv = ImageView(this)
        iv.setImageResource(iconOf(r.status))
        iv.imageTintList = ColorStateList.valueOf(fgOf(r.status))
        icon.addView(iv, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        row.addView(icon, lpL(dp(36), dp(36)))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.addView(tv(r.label, 14f, cDark, true), lpL(wrap, wrap))
        mid.addView(tv((r.txn ?: "No TxnID") + " \u00B7 " + fmtTime(r.receivedAt), 12f, cGray, false), lpL(wrap, wrap))
        val midLp = lpL(0, wrap, 1f)
        midLp.marginStart = dp(12)
        midLp.marginEnd = dp(8)
        row.addView(mid, midLp)

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.END
        right.addView(tv(money(r.amount), 15f, cDark, true), lpL(wrap, wrap))
        val badge = tv(statusText(r.status), 11f, fgOf(r.status), true)
        badge.background = rounded(bgOf(r.status), 999)
        badge.setPadding(dp(10), dp(3), dp(10), dp(3))
        val badgeLp = lpL(wrap, wrap)
        badgeLp.topMargin = dp(4)
        right.addView(badge, badgeLp)
        row.addView(right, lpL(wrap, wrap))
        return row
    }

    // ---------------------------------------------------------------- details dialog

    private fun showDetails(r: SmsRecord) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = rounded(Color.WHITE, 16)
        root.clipToOutline = true

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setBackgroundColor(cBlue1)
        head.setPadding(dp(20), dp(6), dp(6), dp(6))
        head.addView(tv(statusText(r.status), 17f, Color.WHITE, true), lpL(0, wrap, 1f))
        val close = ImageView(this)
        close.setImageResource(R.drawable.ic_close)
        close.imageTintList = ColorStateList.valueOf(Color.WHITE)
        close.setPadding(dp(12), dp(12), dp(12), dp(12))
        close.contentDescription = "Close"
        close.isClickable = true
        close.setOnClickListener { dialog.dismiss() }
        head.addView(close, lpL(dp(44), dp(44)))
        root.addView(head, lpL(match, wrap))

        val rows = ArrayList<DetailRow>()
        rows.add(DetailRow("Provider", r.label, cDark))
        rows.add(DetailRow("Transaction ID", r.txn ?: "Not in SMS", cDark))
        rows.add(DetailRow("Amount", money(r.amount), cDark))
        when (r.status) {
            Status.COMPLETED -> {
                rows.add(DetailRow("Sender", r.fromNumber ?: "Not in SMS", cDark))
                rows.add(DetailRow("SMS Received", fmtTime(r.receivedAt), cDark))
                rows.add(DetailRow("Webhook Sent", fmtTime(r.sentAt), cDark))
            }
            Status.PENDING -> {
                rows.add(DetailRow("Retry Attempt", "${r.attempts} of ${Config.MAX_ATTEMPTS}", cDark))
                rows.add(DetailRow("Last Error", r.lastError ?: "\u2014", Color.parseColor("#C2410C")))
                rows.add(DetailRow("Next Retry", if (r.nextRetryAt > 0) fmtTime(r.nextRetryAt) else "\u2014", cDark))
            }
            else -> {
                rows.add(DetailRow("Total Attempts", "${r.attempts} of ${Config.MAX_ATTEMPTS}", cDark))
                rows.add(DetailRow("Last Error", r.lastError ?: "\u2014", Color.parseColor("#B91C1C")))
            }
        }

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(20), dp(4), dp(20), 0)
        val copyText = StringBuilder()
        for (row in rows) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(0, dp(12), 0, dp(12))
            line.addView(tv(row.label, 13f, cGray, true), lpL(0, wrap, 1f))
            val value = tv(row.value, 14f, row.color, true)
            value.gravity = Gravity.END
            line.addView(value, lpL(wrap, wrap))
            body.addView(line, lpL(match, wrap))
            body.addView(divider(), lpL(match, dp(1)))
            copyText.append(row.label).append(": ").append(row.value).append('\n')
        }
        copyText.append("Status: ").append(statusText(r.status))

        val statusLine = LinearLayout(this)
        statusLine.orientation = LinearLayout.HORIZONTAL
        statusLine.gravity = Gravity.CENTER_VERTICAL
        statusLine.setPadding(0, dp(12), 0, dp(12))
        statusLine.addView(tv("Status", 13f, cGray, true), lpL(0, wrap, 1f))
        val badge = tv(statusText(r.status), 11f, fgOf(r.status), true)
        badge.background = rounded(bgOf(r.status), 999)
        badge.setPadding(dp(10), dp(3), dp(10), dp(3))
        statusLine.addView(badge, lpL(wrap, wrap))
        body.addView(statusLine, lpL(match, wrap))
        root.addView(body, lpL(match, wrap))

        val actionText = when (r.status) {
            Status.COMPLETED -> "Copy Details"
            Status.PENDING -> "Retry Now"
            else -> "Manual Retry"
        }
        val action = button(actionText, Color.WHITE, solidOf(r.status))
        action.setOnClickListener {
            when (r.status) {
                Status.COMPLETED -> {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Resellic Pay", copyText.toString()))
                    action.text = "Copied"
                }
                Status.PENDING -> {
                    Scheduler.now(applicationContext, r.id)
                    toast("Retrying\u2026")
                    dialog.dismiss()
                }
                else -> {
                    Db.get(this).update(r.id, Status.PENDING, 0, null, 0L, 0L)
                    Scheduler.now(applicationContext, r.id)
                    toast("Retrying\u2026")
                    dialog.dismiss()
                    lastSig = ""
                    renderData()
                }
            }
        }
        val actionLp = lpL(match, wrap)
        actionLp.setMargins(dp(20), dp(8), dp(20), dp(20))
        root.addView(action, actionLp)

        dialog.setContentView(root)
        dialog.show()
        val w = dialog.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        }
    }

    // ---------------------------------------------------------------- Settings

    private fun buildSettings(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))

        // ---- API configuration
        val api = card("API Configuration", null)
        val apiBody = LinearLayout(this)
        apiBody.orientation = LinearLayout.VERTICAL
        apiBody.setPadding(dp(16), dp(16), dp(16), dp(16))
        apiBody.addView(tv("One token for all payment methods", 12f, cGray, true), lpL(wrap, wrap))

        val field = EditText(this)
        tokenField = field
        field.setSingleLine(true)
        field.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        field.setText(maskToken(Config.token(this)))
        field.setTextColor(Color.WHITE)
        field.setHintTextColor(Color.parseColor("#94A3B8"))
        field.textSize = 15f
        field.typeface = Typeface.DEFAULT_BOLD
        field.gravity = Gravity.CENTER
        val fieldBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cDark, Color.parseColor("#1E293B")))
        fieldBg.cornerRadius = dp(10).toFloat()
        field.background = fieldBg
        field.setPadding(dp(16), dp(14), dp(16), dp(14))
        setTokenEditable(false)
        val fieldLp = lpL(match, wrap)
        fieldLp.topMargin = dp(12)
        apiBody.addView(field, fieldLp)

        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        val change = button("CHANGE TOKEN", Color.WHITE, cDark)
        val save = button("SAVE TOKEN", Color.WHITE, cDark)
        val changeLp = lpL(0, wrap, 1f)
        changeLp.marginEnd = dp(5)
        val saveLp = lpL(0, wrap, 1f)
        saveLp.marginStart = dp(5)
        btnRow.addView(change, changeLp)
        btnRow.addView(save, saveLp)
        val btnLp = lpL(match, wrap)
        btnLp.topMargin = dp(12)
        apiBody.addView(btnRow, btnLp)
        api.addView(apiBody, lpL(match, wrap))

        change.setOnClickListener {
            val f = tokenField
            if (f != null) {
                setTokenEditable(true)
                f.setText("")
                f.hint = "Paste token here"
                f.requestFocus()
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(f, InputMethodManager.SHOW_IMPLICIT)
            }
        }
        save.setOnClickListener {
            val f = tokenField
            if (f != null) {
                if (!editingToken) {
                    toast("Tap CHANGE TOKEN first")
                } else {
                    val t = f.text.toString().trim()
                    if (t.isEmpty()) {
                        toast("Paste the token first")
                    } else {
                        Config.setToken(this, t)
                        setTokenEditable(false)
                        f.setText(maskToken(t))
                        f.clearFocus()
                        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.hideSoftInputFromWindow(f.windowToken, 0)
                        toast("Token saved")
                        for (rec in Db.get(this).pending()) Scheduler.now(applicationContext, rec.id)
                        updatePill()
                        checkServer()
                    }
                }
            }
        }

        col.addView(api, lpL(match, wrap))

        // ---- permissions
        val badge = tv("0/4 Granted", 12f, Color.parseColor("#166534"), true)
        badge.setPadding(dp(10), dp(5), dp(10), dp(5))
        badge.background = rounded(Color.parseColor("#DCFCE7"), 999)
        permBadge = badge

        val perms = card("Permissions", badge)
        perms.addView(permRow(0, "Receive SMS", "Allow app to receive incoming payment SMS"), lpL(match, wrap))
        perms.addView(divider(), lpL(match, dp(1)))
        perms.addView(permRow(1, "Read SMS", "Allow app to read SMS for sync"), lpL(match, wrap))
        perms.addView(divider(), lpL(match, dp(1)))
        perms.addView(permRow(2, "Battery Optimization", "Allow app to stay active during sync"), lpL(match, wrap))
        perms.addView(divider(), lpL(match, dp(1)))
        perms.addView(permRow(3, "Auto Start", "Allow app to start on device boot"), lpL(match, wrap))
        val permsLp = lpL(match, wrap)
        permsLp.topMargin = dp(12)
        col.addView(perms, permsLp)

        sv.addView(col)
        return sv
    }

    private fun setTokenEditable(on: Boolean) {
        val f = tokenField ?: return
        editingToken = on
        f.isFocusable = on
        f.isFocusableInTouchMode = on
        f.isCursorVisible = on
        f.isLongClickable = on
    }

    private fun maskToken(t: String): String {
        if (t.isBlank()) return "Not configured"
        if (t.length <= 8) return "\u2022\u2022\u2022\u2022"
        return t.take(4) + " \u00B7\u00B7\u00B7\u00B7\u00B7\u00B7\u00B7\u00B7\u00B7\u00B7\u00B7\u00B7 " + t.takeLast(4)
    }

    private fun permRow(index: Int, title: String, desc: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        row.minimumHeight = dp(64)

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(tv(title, 14f, cDark, true), lpL(wrap, wrap))
        val d = tv(desc, 12f, cGray, false)
        texts.addView(d, lpL(wrap, wrap))
        val textsLp = lpL(0, wrap, 1f)
        textsLp.marginEnd = dp(12)
        row.addView(texts, textsLp)

        val sw = Switch(this)
        sw.contentDescription = title
        sw.setOnCheckedChangeListener { _, checked -> onPermToggle(index, checked) }
        permSwitches.add(sw)
        row.addView(sw, lpL(wrap, wrap))
        return row
    }

    private fun refreshPerms() {
        if (permSwitches.size < 4) return
        val states = booleanArrayOf(
            hasPerm(Manifest.permission.RECEIVE_SMS),
            hasPerm(Manifest.permission.READ_SMS),
            batteryOk(),
            Config.autoStart(this)
        )
        suppressToggle = true
        for (i in 0..3) permSwitches[i].isChecked = states[i]
        suppressToggle = false

        val granted = states.count { it }
        val b = permBadge
        if (b != null) {
            b.text = "$granted/4 Granted"
            b.setTextColor(Color.parseColor(if (granted == 4) "#166534" else "#9A3412"))
            b.background = rounded(Color.parseColor(if (granted == 4) "#DCFCE7" else "#FFEDD5"), 999)
        }
    }

    private fun onPermToggle(index: Int, on: Boolean) {
        if (suppressToggle) return
        when (index) {
            0 -> {
                if (on) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), RC_TOGGLE) else openAppSettings()
            }
            1 -> {
                if (on) requestPermissions(arrayOf(Manifest.permission.READ_SMS), RC_TOGGLE) else openAppSettings()
            }
            2 -> {
                try {
                    if (on) {
                        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        i.data = Uri.parse("package:$packageName")
                        startActivity(i)
                    } else {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                } catch (e: Exception) {
                    openAppSettings()
                }
            }
            else -> {
                Config.setAutoStart(this, on)
                refreshPerms()
            }
        }
    }

    private fun hasPerm(p: String): Boolean = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun batteryOk(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun openAppSettings() {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) {
            toast("Open app settings manually")
        }
    }

    // ---------------------------------------------------------------- scan / server

    private fun scanInbox() {
        if (!hasPerm(Manifest.permission.READ_SMS)) {
            toast("Allow Read SMS first")
            requestPermissions(arrayOf(Manifest.permission.READ_SMS), RC_TOGGLE)
            return
        }
        toast("Scanning\u2026")
        val app = applicationContext
        thread {
            var added = 0
            try {
                val since = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
                val cursor = contentResolver.query(
                    Telephony.Sms.Inbox.CONTENT_URI,
                    arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                    Telephony.Sms.DATE + " >= ?",
                    arrayOf(since.toString()),
                    Telephony.Sms.DATE + " ASC"
                )
                if (cursor != null) {
                    cursor.use { c ->
                        while (c.moveToNext()) {
                            val addr = c.getString(0)
                            val body = c.getString(1)
                            val date = c.getLong(2)
                            if (addr != null && body != null) {
                                if (Ingest.handle(app, addr, body, date, true) > 0) added++
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore: reported as 0 new below
            }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    toast(if (added == 0) "Scan complete: nothing new" else "Scan complete: $added new")
                    lastSig = ""
                    renderData()
                }
            }
        }
    }

    private fun checkServer() {
        thread {
            val ok = try {
                val c = URL(Config.ENDPOINT).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.requestMethod = "GET"
                c.responseCode
                c.disconnect()
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    serverOk = ok
                    updatePill()
                }
            }
        }
    }

    // ---------------------------------------------------------------- view helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun lpL(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight)

    private fun gradient(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cBlue1, cBlue2))

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(color)
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    private fun ripple(base: Int): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#1F1E40AF")), ColorDrawable(base), null)

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(cLine)
        return v
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun button(text: String, textColor: Int, bgColor: Int): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(textColor)
        b.textSize = 13f
        b.typeface = Typeface.DEFAULT_BOLD
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.minWidth = 0
        b.background = rounded(bgColor, 10)
        return b
    }

    private fun card(title: String, right: View?): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(Color.WHITE, 14, cLine)
        card.clipToOutline = true

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.background = gradient()
        head.setPadding(dp(16), dp(6), dp(12), dp(6))
        head.minimumHeight = dp(52)
        head.addView(tv(title, 15f, Color.WHITE, true), lpL(0, wrap, 1f))
        if (right != null) head.addView(right, lpL(wrap, wrap))
        card.addView(head, lpL(match, wrap))
        return card
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun money(v: Double): String = "\u09F3" + String.format(Locale.US, "%,.2f", v)

    private fun fmtTime(t: Long): String {
        if (t <= 0L) return "\u2014"
        val then = Calendar.getInstance()
        then.timeInMillis = t
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance()
        yesterday.add(Calendar.DAY_OF_YEAR, -1)
        val clock = SimpleDateFormat("h:mm a", Locale.US).format(Date(t))
        if (sameDay(then, today)) return "Today, $clock"
        if (sameDay(then, yesterday)) return "Yesterday, $clock"
        return SimpleDateFormat("d MMM, h:mm a", Locale.US).format(Date(t))
    }

    private fun sameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    private fun fgOf(s: String): Int = Color.parseColor(
        when (s) {
            Status.COMPLETED -> "#166534"
            Status.PENDING -> "#9A3412"
            else -> "#991B1B"
        }
    )

    private fun bgOf(s: String): Int = Color.parseColor(
        when (s) {
            Status.COMPLETED -> "#DCFCE7"
            Status.PENDING -> "#FFEDD5"
            else -> "#FEE2E2"
        }
    )

    private fun solidOf(s: String): Int = Color.parseColor(
        when (s) {
            Status.COMPLETED -> "#15803D"
            Status.PENDING -> "#C2410C"
            else -> "#B91C1C"
        }
    )

    private fun statusText(s: String): String = when (s) {
        Status.COMPLETED -> "Completed"
        Status.PENDING -> "Pending"
        else -> "Failed"
    }

    private fun iconOf(s: String): Int = when (s) {
        Status.COMPLETED -> R.drawable.ic_check
        Status.PENDING -> R.drawable.ic_clock
        else -> R.drawable.ic_close
    }
}
