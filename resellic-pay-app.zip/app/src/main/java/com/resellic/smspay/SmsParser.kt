package com.resellic.smspay

data class Parsed(
    val label: String,
    val key: String,
    val amount: Double,
    val txn: String?,
    val fromNumber: String?
)

object SmsParser {
    private const val NUM = "([0-9][0-9,]*(?:\\.[0-9]+)?)"
    private val OPT = setOf(RegexOption.IGNORE_CASE)

    private val BKASH_AMOUNT = Regex("received\\s+Tk\\.?\\s*$NUM", OPT)
    private val BKASH_TXN = Regex("TrxID\\s*[:\\-]?\\s*([A-Z0-9]+)", OPT)
    private val BKASH_FROM = Regex("from\\s+(01[0-9]{9})", OPT)

    private val NAGAD_AMOUNT = Regex("Amount:?\\s*Tk\\.?\\s*$NUM", OPT)
    private val NAGAD_TXN = Regex("Txn\\s*ID\\s*[:\\-]?\\s*([A-Z0-9]+)", OPT)
    private val NAGAD_FROM = Regex("(?:Sender|Customer):?\\s*(01[0-9]{9})", OPT)

    private val BRAC_AMOUNT = Regex("credited\\s+by\\s+TK\\.?\\s*$NUM", OPT)

    /** Returns null when the SMS is not a "money received" SMS from a supported sender. */
    fun parse(address: String, body: String): Parsed? {
        val a = address.lowercase()
        return when {
            a.contains("bkash") -> bkash(body)
            a.contains("nagad") -> nagad(body)
            a.contains("brac") -> brac(body)
            else -> null
        }
    }

    private fun amountOf(s: String): Double? = s.replace(",", "").toDoubleOrNull()

    private fun bkash(b: String): Parsed? {
        val amount = BKASH_AMOUNT.find(b)?.groupValues?.get(1)?.let { amountOf(it) } ?: return null
        return Parsed(
            "bKash Personal", "bkash", amount,
            BKASH_TXN.find(b)?.groupValues?.get(1),
            BKASH_FROM.find(b)?.groupValues?.get(1)
        )
    }

    private fun nagad(b: String): Parsed? {
        val label = when {
            b.contains("Bangla QR", ignoreCase = true) -> "Nagad Bangla QR"
            b.contains("Payment Received", ignoreCase = true) -> "Nagad Merchant"
            b.contains("Money Received", ignoreCase = true) -> "Nagad Personal"
            else -> return null
        }
        val amount = NAGAD_AMOUNT.find(b)?.groupValues?.get(1)?.let { amountOf(it) } ?: return null
        return Parsed(
            label, "nagad", amount,
            NAGAD_TXN.find(b)?.groupValues?.get(1),
            NAGAD_FROM.find(b)?.groupValues?.get(1)
        )
    }

    private fun brac(b: String): Parsed? {
        if (!b.contains("has been credited by", ignoreCase = true)) return null
        val amount = BRAC_AMOUNT.find(b)?.groupValues?.get(1)?.let { amountOf(it) } ?: return null
        return Parsed("BRAC Bank", "bank_brac_bank", amount, null, null)
    }
}
