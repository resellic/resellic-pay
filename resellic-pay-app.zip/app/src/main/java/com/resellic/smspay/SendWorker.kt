package com.resellic.smspay

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class SendWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val id = inputData.getLong("id", -1L)
        if (id < 0) return Result.success()

        val ctx = applicationContext
        val db = Db.get(ctx)
        val rec = db.get(id) ?: return Result.success()
        if (rec.status == Status.COMPLETED) return Result.success()

        val token = Config.token(ctx)
        if (token.isBlank()) {
            db.update(id, Status.PENDING, rec.attempts, "Token not set", 0L, 0L)
            return Result.success()
        }

        val attempts = rec.attempts + 1
        val error = Api.send(rec, token)
        val now = System.currentTimeMillis()

        if (error == null) {
            db.update(id, Status.COMPLETED, attempts, null, 0L, now)
            Notifier.sent(ctx, rec)
        } else if (attempts >= Config.MAX_ATTEMPTS) {
            db.update(id, Status.FAILED, attempts, error, 0L, 0L)
            Notifier.failed(ctx, rec, error)
        } else {
            val delay = Config.RETRY_DELAYS_MIN[attempts - 1]
            db.update(id, Status.PENDING, attempts, error, now + delay * 60_000L, 0L)
            Scheduler.later(ctx, id, delay)
        }
        return Result.success()
    }
}
