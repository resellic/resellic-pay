package com.resellic.smspay

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class SendWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val id = inputData.getLong("id", -1L)
        if (id < 0) return Result.success()

        val ctx = applicationContext
        val db = Db.get(ctx)
        val rec = db.get(id) ?: return Result.success()
        if (rec.status == Status.COMPLETED || rec.status == Status.UNMATCHED) return Result.success()

        val token = Config.token(ctx)
        if (token.isBlank()) {
            db.update(id, Status.PENDING, rec.attempts, "Token not set", 0L, 0L)
            return Result.success()
        }

        val attempts = rec.attempts + 1
        val now = System.currentTimeMillis()

        when (val result = Api.send(rec, token)) {
            is ApiResult.Matched -> {
                db.update(id, Status.COMPLETED, attempts, null, 0L, now)
                Notifier.sent(ctx, rec)
            }
            is ApiResult.Unmatched -> {
                // পৌঁছেছে, লগ হয়েছে — কিন্তু কোনো অর্ডারের amount-এর সাথে মেলেনি।
                // retry করে লাভ নেই (amount তো একই থাকবে), তাই এখানেই থেমে যাওয়া —
                // অ্যাডমিন প্যানেল থেকে ম্যানুয়ালি মিলিয়ে দিতে হবে।
                db.update(id, Status.UNMATCHED, attempts, "কোনো পেন্ডিং অর্ডারের amount-এর সাথে মেলেনি", 0L, now)
                Notifier.unmatched(ctx, rec)
            }
            is ApiResult.Error -> {
                if (attempts >= Config.MAX_ATTEMPTS) {
                    db.update(id, Status.FAILED, attempts, result.message, 0L, 0L)
                    Notifier.failed(ctx, rec, result.message)
                } else {
                    val delay = Config.RETRY_DELAYS_MIN[attempts - 1]
                    db.update(id, Status.PENDING, attempts, result.message, now + delay * 60_000L, 0L)
                    Scheduler.later(ctx, id, delay)
                }
            }
        }
        return Result.success()
    }
}
