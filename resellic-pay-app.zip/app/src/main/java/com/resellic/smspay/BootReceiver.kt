package com.resellic.smspay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Config.autoStart(context)) return
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                for (rec in Db.get(app).pending()) Scheduler.now(app, rec.id)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
