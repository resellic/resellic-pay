package com.resellic.smspay

import android.content.Context

object Config {
    const val ENDPOINT = "https://pay.resellic.com/api/sms-verified.php"
    const val MAX_ATTEMPTS = 5

    /** Wait (minutes) after failed attempt 1, 2, 3, 4. */
    val RETRY_DELAYS_MIN = longArrayOf(1L, 2L, 5L, 10L)

    private const val PREFS = "resellic_pay"
    private const val KEY_TOKEN = "token"
    private const val KEY_AUTOSTART = "autostart"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun token(ctx: Context): String = prefs(ctx).getString(KEY_TOKEN, "") ?: ""

    fun setToken(ctx: Context, value: String) {
        prefs(ctx).edit().putString(KEY_TOKEN, value).apply()
    }

    fun autoStart(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AUTOSTART, true)

    fun setAutoStart(ctx: Context, value: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_AUTOSTART, value).apply()
    }
}
