package com.resellic.smspay

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Api {
    /** Sends one SMS to the server. Returns null on success, otherwise an error text. */
    fun send(rec: SmsRecord, token: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val received = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date(rec.receivedAt))
            val json = JSONObject()
            json.put("provider", rec.key)
            json.put("sender", rec.address)
            json.put("sender_number", rec.fromNumber ?: JSONObject.NULL)
            json.put("amount", rec.amount)
            json.put("txn_id", rec.txn ?: JSONObject.NULL)
            json.put("raw_sms", rec.body)
            json.put("body", rec.body)
            json.put("received_at", received)
            json.put("token", token)
            val bytes = json.toString().toByteArray(Charsets.UTF_8)

            val c = URL(Config.ENDPOINT).openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("X-Api-Key", token)
            c.outputStream.use { it.write(bytes) }

            val code = c.responseCode
            if (code in 200..299) null else "HTTP $code"
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        } finally {
            conn?.disconnect()
        }
    }
}
