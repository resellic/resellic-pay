package com.resellic.smspay

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** সার্ভারের রেসপন্স তিনভাবে হতে পারে:
 *  - Matched: SMS পৌঁছেছে এবং কোনো পেন্ডিং অর্ডারের সাথে মিলে গেছে (amount হুবহু মিলেছে) → Completed
 *  - Unmatched: SMS পৌঁছেছে, লগ হয়েছে, কিন্তু কোনো অর্ডারের amount-এর সাথে মেলেনি → Unmatched
 *    (retry করে লাভ নেই — টাকার অঙ্কই তো মিলছে না, বারবার পাঠালেও মিলবে না)
 *  - Error: নেটওয়ার্ক/সার্ভার এরর, request-ই পৌঁছায়নি → retry হবে
 */
sealed class ApiResult {
    data class Matched(val orderId: String?) : ApiResult()
    object Unmatched : ApiResult()
    data class Error(val message: String) : ApiResult()
}

object Api {
    /** সার্ভারে একটা SMS পাঠায় এবং রেসপন্স JSON থেকে matched/unmatched/error বের করে। */
    fun send(rec: SmsRecord, token: String): ApiResult {
        var conn: HttpURLConnection? = null
        return try {
            val received = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date(rec.receivedAt))
            val json = JSONObject()
            json.put("provider", rec.key)
            json.put("sender", rec.address)
            json.put("sender_number", rec.fromNumber ?: JSONObject.NULL)
            json.put("amount", rec.amount)
            json.put("txn_id", rec.txn ?: JSONObject.NULL)
            json.put("raw_sms", rec.body)
            json.put("body", rec.body)
            json.put("received_at", received)
            json.put("token", token)
            val bytes = json.toString().toByteArray(Charsets.UTF_8)

            val c = URL(Config.ENDPOINT).openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("X-Api-Key", token)
            c.outputStream.use { it.write(bytes) }

            val code = c.responseCode
            if (code !in 200..299) {
                return ApiResult.Error("HTTP $code")
            }

            val body = (c.errorStream ?: c.inputStream).bufferedReader().use { it.readText() }
            val resp = try { JSONObject(body) } catch (e: Exception) { null }

            // সার্ভার JSON বুঝতে না পারলে unmatched ধরা হচ্ছে (false) —
            // আগে true ছিল, তাতে match না হলেও ভুলভাবে Completed দেখাত।
            // resp থাকলে matched ফিল্ডটাই আসল সত্য।
            val matched = resp?.optBoolean("matched", false) ?: false
            if (matched) {
                ApiResult.Matched(resp?.optString("order_id")?.takeIf { it.isNotBlank() })
            } else {
                ApiResult.Unmatched
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: e.javaClass.simpleName)
        } finally {
            conn?.disconnect()
        }
    }
}
