# Resellic Pay – SMS app

Forwards payment SMS (bKash, Nagad, BRAC Bank) to pay.resellic.com.

- Target: Android 16 (API 36)
- Endpoint: `POST https://pay.resellic.com/api/sms-verified.php`
- Auth: one token, sent as header `X-Api-Key` (also as `token` in the JSON)
- Retry: up to 5 attempts (wait 1, 2, 5, 10 min), survives reboot

## JSON sent to the server

```json
{
  "provider": "bkash | nagad | bank_brac_bank",
  "sender": "bKash",
  "sender_number": "01XXXXXXXXX or null",
  "amount": 1234.56,
  "txn_id": "8N2K5D3F or null",
  "raw_sms": "full SMS text",
  "body": "full SMS text",
  "received_at": "2026-09-20T14:32:10+0600",
  "token": "same as X-Api-Key"
}
```

Nagad Personal, Nagad Merchant and Nagad Bangla QR all use `provider = nagad`.
The server answers HTTP 2xx when it accepted the SMS; anything else is retried.
